import hashlib
import json
import re
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

base = Path('D:/Temp/Neoxider-Audit-20261101/native-20261102')
name = sys.argv[1]
if not name or any(character not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for character in name):
    raise SystemExit('Invalid owned run name')
run = base / name
root = ET.parse(run / 'results.xml').getroot()
pattern = re.compile(r'CTA readback capture: path=(.+?), size=(\d+)x(\d+), bytes=(\d+), sha256=([0-9a-f]{64})')
records = []
for case in root.iter('test-case'):
    for match in pattern.finditer(case.findtext('output') or ''):
        path = Path(match[1])
        if path.parent.resolve() != (run / 'readback').resolve():
            raise SystemExit('Capture path is not within the owned run/readback')
        content = path.read_bytes()
        assert content[:8] == b'\x89PNG\r\n\x1a\n'
        width, height = struct.unpack('>II', content[16:24])
        digest = hashlib.sha256(content).hexdigest()
        assert width == int(match[2]) and height == int(match[3])
        assert len(content) == int(match[4]) and digest == match[5]
        records.append({'test': case.get('fullname'), 'result': case.get('result'), 'file': path.name, 'width': width, 'height': height, 'bytes': len(content), 'sha256': digest})
assert len(records) == 2 and len({entry['file'] for entry in records}) == 2
receipt = {'source': 'Exact Texture2D ReadPixels/Apply PNG before pixel assertions; metadata independently matched to XML output', 'captures': records, 'isVideo': False, 'isOrdinaryGameView': False, 'isPhysicalInput': False}
(run / 'captures.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
