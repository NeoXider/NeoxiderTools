using DG.Tweening;
using Neo.Extensions;
using Neo.Reactive;
using Neo.Save;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Neo.Bonus
{
    [NeoDoc("Bonus/Collection/Box.md")]
    [CreateFromMenu("Neoxider/Bonus/Box")]
    [AddComponentMenu("Neoxider/" + "Bonus/" + nameof(Box))]
    public class Box : MonoBehaviour
    {
        [SerializeField] private string _saveName = "BoxPrize";

        [Space] [Header("View")] [SerializeField]
        private Image _boxImage;

        [SerializeField] private Sprite[] _boxSpritesCloseOpen = new Sprite[2];
        [SerializeField] private Image _bar;
        [SerializeField] private TMP_Text _textProgress;
        [SerializeField] private TMP_Text _textMaxProgress;
        [SerializeField] private TMP_Text _textProgressMaxProgress;

        [Space] [Header("Animation and prize")] [SerializeField]
        private GameObject _animItem;

        [SerializeField] private Ease _ease = Ease.InCubic;
        [SerializeField] private Image _itemPrize;

        [SerializeField] private float _addProgress = 100f;
        [SerializeField] private float _maxProgress = 300f;
        [SerializeField] private float _progress;
        private bool _takingPrize;
        private ulong _progressWriteRevision;

        [Space] public UnityEvent OnTakePrize;
        public UnityEvent OnProgressReached;
        public UnityEvent OnProgressNotReached;
        public UnityEvent<bool> OnChangeProgress;

        [Tooltip("Reactive progress value; subscribe via Progress.OnChanged")]
        public ReactivePropertyFloat Progress = new();

        public float AddProgressAmount => _addProgress;
        public float MaxProgress => _maxProgress;

        /// <summary>Current progress (for NeoCondition and reflection).</summary>
        public float ProgressValue => Progress.CurrentValue;

        public float progress
        {
            get => _progress;
            set
            {
                // Save observers can supersede this write, including with the same value.
                ulong revision = ++_progressWriteRevision;
                _progress = value;
                SaveProvider.SetFloat(_saveName + nameof(progress), value);
                if (revision != _progressWriteRevision)
                {
                    return;
                }

                Progress.Value = value;
                if (revision == _progressWriteRevision)
                {
                    Visual();
                }
            }
        }

        public bool CheckProgress
        {
            get
            {
                float currentProgress = progress;
                return currentProgress >= _maxProgress &&
                       (_maxProgress <= 0f ||
                        (float.IsFinite(currentProgress) && float.IsFinite(_maxProgress) &&
                         GetProgressAfterPrize(currentProgress) < currentProgress));
            }
        }

        private void Awake()
        {
            _progress = SaveProvider.GetFloat(_saveName + nameof(progress));
            Progress.Value = _progress;
        }

        private void OnEnable()
        {
            if (_animItem != null)
            {
                _animItem.transform.localScale = Vector3.zero;
            }

            Visual();
            Events();
        }

        public void AddProgress()
        {
            AddProgress(_addProgress);
        }

        [Button]
        public void AddProgress(float amount)
        {
            ChangeProgress(amount);
        }

        [Button]
        public void ChangeProgress(float amount)
        {
            progress += amount;
            Events();
        }

        private void Events()
        {
            bool progressOpen = CheckProgress;

            OnChangeProgress?.Invoke(progressOpen);

            if (progressOpen)
            {
                OnProgressReached?.Invoke();
            }
            else
            {
                OnProgressNotReached?.Invoke();
            }
        }

        [Button]
        public void TakePrize()
        {
            if (CheckProgress && !_takingPrize)
            {
                Collection collection = Collection.I;
                if (collection == null)
                {
                    NeoDiagnostics.LogWarning("[Box] No Collection in the scene — cannot take a prize.", this);
                    return;
                }

                _takingPrize = true;
                try
                {
                    ItemCollectionData itemData = collection.GetPrize(CommitPrizeProgress);
                    if (itemData == null)
                    {
                        return;
                    }

                    if (_itemPrize != null)
                    {
                        _itemPrize.sprite = itemData.Sprite;
                    }

                    if (_animItem != null)
                    {
                        _animItem.transform.DOScale(1, 2).SetEase(_ease);
                    }

                    Visual(true);

                    OnTakePrize?.Invoke();
                }
                finally
                {
                    _takingPrize = false;
                }
            }
        }

        private void CommitPrizeProgress()
        {
            progress = GetProgressAfterPrize(progress);
            Events();
        }

        private float GetProgressAfterPrize(float currentProgress)
        {
            return Mathf.Max(0f, currentProgress - _maxProgress);
        }

        [Button]
        private void Visual(bool openBox = false)
        {
            if (_bar != null)
            {
                _bar.fillAmount = _maxProgress > 0f ? Mathf.Clamp01(progress / _maxProgress) : 0f;
            }

            if (_boxImage != null && _boxSpritesCloseOpen != null && _boxSpritesCloseOpen.Length >= 2)
            {
                _boxImage.sprite = _boxSpritesCloseOpen[openBox ? 1 : 0];
                _boxImage.SetNativeSize();
            }

            if (_textProgress != null)
            {
                _textProgress.text = $"{progress.RoundToDecimal(0)}";
            }

            if (_textMaxProgress != null)
            {
                _textMaxProgress.text = $"{_maxProgress.RoundToDecimal(0)}";
            }

            if (_textProgressMaxProgress != null)
            {
                _textProgressMaxProgress.text = $"{progress.RoundToDecimal(0)}/{_maxProgress.RoundToDecimal(0)}";
            }
        }
    }
}
