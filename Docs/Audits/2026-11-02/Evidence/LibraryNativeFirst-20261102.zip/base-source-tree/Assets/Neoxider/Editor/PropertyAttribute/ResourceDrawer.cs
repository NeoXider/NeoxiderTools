using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Neo.Editor
{
    /// <summary>
    ///     Handles resource-related functionality in the custom editor
    /// </summary>
    public static class ResourceDrawer
    {
        public static void ProcessResourceAttributes(MonoBehaviour targetObject)
        {
            if (!NeoxiderSettings.EnableAttributeSearch)
            {
                return;
            }

            FieldInfo[] fields = targetObject.GetType().GetFields(CustomEditorBase.FIELD_FLAGS);

            foreach (FieldInfo field in fields)
            {
                object fieldValue = field.GetValue(targetObject);
                // WHY: A field whose asset was deleted holds a "fake null" Unity wrapper (!= managed null);
                // treat it as unassigned so [LoadFromResources] can repopulate it, matching ComponentDrawer.
                bool isNull = fieldValue == null || (fieldValue is Object obj && obj == null);

                if (isNull)
                {
                    ProcessNullField(field, targetObject);
                }
                else if (IsEmptyCollection(fieldValue))
                {
                    ProcessEmptyCollection(field, targetObject);
                }
            }
        }

        private static void ProcessNullField(FieldInfo field, MonoBehaviour targetObject)
        {
            if (HasAttribute<LoadFromResourcesAttribute>(field))
            {
                AssignResource(field, targetObject);
            }
            else if (HasAttribute<LoadAllFromResourcesAttribute>(field))
            {
                AssignAllResources(field, targetObject);
            }
        }

        private static void ProcessEmptyCollection(FieldInfo field, MonoBehaviour targetObject)
        {
            if (HasAttribute<LoadAllFromResourcesAttribute>(field))
            {
                AssignAllResources(field, targetObject);
            }
        }

        private static void AssignResource(FieldInfo field, MonoBehaviour targetObject)
        {
            var attribute = field.GetCustomAttributes(typeof(LoadFromResourcesAttribute), false)
                .FirstOrDefault() as LoadFromResourcesAttribute;
            if (attribute == null)
            {
                return;
            }

            string resourcePath = attribute.ResourcePath;
            Type resourceType = field.FieldType;
            Object resource = null;

            if (!string.IsNullOrEmpty(resourcePath))
            {
                resource = Resources.Load(resourcePath, resourceType);
            }

            if (resource == null)
            {
                Object[] resources = Resources.FindObjectsOfTypeAll(resourceType);
                resource = resources.FirstOrDefault();
            }

            if (resource != null)
            {
                field.SetValue(targetObject, resource);
                EditorUtility.SetDirty(targetObject);
            }
            else
            {
                Debug.LogWarning(
                    $"{resourceType} for field '{field.Name}' not found at Resources path: '{resourcePath}'.");
            }
        }

        private static void AssignAllResources(FieldInfo field, MonoBehaviour targetObject)
        {
            var attribute = field
                .GetCustomAttributes(typeof(LoadAllFromResourcesAttribute), false)
                .FirstOrDefault() as LoadAllFromResourcesAttribute;
            if (attribute == null)
            {
                return;
            }

            Type elementType = GetElementType(field);
            if (elementType == null)
            {
                Debug.LogWarning($"Field '{field.Name}': unable to determine element type for resource loading.");
                return;
            }

            object[] resources;
            if (!string.IsNullOrEmpty(attribute.ResourcePath))
            {
                resources = Resources.LoadAll(attribute.ResourcePath, elementType);
            }
            else
            {
                resources = Resources.FindObjectsOfTypeAll(elementType);
            }

            if (resources != null && resources.Length > 0)
            {
                Array typedArray = Array.CreateInstance(elementType, resources.Length);
                Array.Copy(resources, typedArray, resources.Length);

                ComponentDrawer.SetFieldValueForCollection(field, targetObject, typedArray);
                EditorUtility.SetDirty(targetObject);
            }
        }

        private static bool HasAttribute<T>(FieldInfo field) where T : Attribute
        {
            return field.GetCustomAttributes(typeof(T), false).Length > 0;
        }

        private static bool IsEmptyCollection(object value)
        {
            return (value is Array arr && arr.Length == 0) ||
                   (value is IList list && list.Count == 0);
        }

        private static Type GetElementType(FieldInfo field)
        {
            if (field.FieldType.IsArray)
            {
                return field.FieldType.GetElementType();
            }

            if (field.FieldType.IsGenericType)
            {
                Type genericType = field.FieldType.GetGenericTypeDefinition();
                if (genericType == typeof(List<>) ||
                    genericType == typeof(IList<>) ||
                    genericType == typeof(ICollection<>) ||
                    genericType == typeof(IEnumerable<>))
                {
                    Type[] args = field.FieldType.GetGenericArguments();
                    if (args.Length > 0)
                    {
                        return args[0];
                    }
                }
            }

            return null;
        }
    }
}
