"""Adapt the existing showcase managed-DLL typecheck recipe; never start Unity."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path('D:/Git/NeoxiderTools')
TASK = Path(__file__).resolve().parent / 'api-typecheck'
LEGACY = Path('D:/Temp/Neoxider-HtmlDemo/site-work/typecheck.py')
RUNTIME = ROOT / 'Assets/Neoxider/Scripts/UI/HtmlToUitk/Runtime'
EDITOR = ROOT / 'Assets/Neoxider/Scripts/UI/HtmlToUitk/Editor'
TESTS = [ROOT / 'Assets/Neoxider/Tests/Edit/HtmlToUitk/HtmlRuntimeWebContractsTests.cs',
         ROOT / 'Assets/Neoxider/Tests/Edit/HtmlToUitk/Editor/Audit20261101NeoHtmlToUitkEditorDraftTests.cs']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sources(directory):
    return sorted(p for p in directory.rglob('*.cs') if not any(x.endswith('~') for x in p.relative_to(directory).parts))

if TASK.exists():
    raise SystemExit('API preflight directory already exists; refusing to overwrite evidence')
TASK.mkdir(parents=True)
snapshot = TASK / 'source-snapshot'
manifest = {'qualification': 'API-only netstandard2.1/C#9 compilation against actual installed managed DLLs; not Unity import, execution or a build of precompiled dependencies',
            'reuseRecipe': str(LEGACY), 'reuseRecipeSha256': digest(LEGACY), 'sources': {}, 'sdkProfiles': {}}
groups = {'Runtime': sources(RUNTIME), 'Editor': sources(EDITOR), 'Tests': TESTS}
copies = {}
for group, inputs in groups.items():
    copies[group] = []
    for path in inputs:
        relative = path.relative_to(ROOT)
        target = snapshot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        copies[group].append(target)
        manifest['sources'][str(path)] = {'snapshot': str(target), 'sha256': digest(path)}

extension = ROOT / 'Library/ScriptAssemblies/Neo.Extensions.dll'
nunit = ROOT / 'Library/PackageCache/com.unity.ext.nunit@d8c07649098d/net40/unity-custom/nunit.framework.dll'
runners = [ROOT / 'Library/ScriptAssemblies/UnityEngine.TestRunner.dll', ROOT / 'Library/ScriptAssemblies/UnityEditor.TestRunner.dll']
for path in [extension, nunit, *runners]:
    if not path.is_file():
        raise SystemExit('Required real dependency is absent: ' + str(path))

for version, minor in [('6000.3.14f1', 3), ('6000.6.0f1', 6)]:
    managed = Path('C:/Program Files/Unity/Hub/Editor') / version / 'Editor/Data/Managed/UnityEngine'
    unity_refs = sorted(managed.glob('*.dll'))
    if not unity_refs:
        raise SystemExit('Installed Unity managed modules not found: ' + str(managed))
    defines = ['UNITY_EDITOR', 'UNITY_INCLUDE_TESTS', 'UNITY_STANDALONE_WIN', 'UNITY_STANDALONE', 'UNITY_64']
    defines += ['UNITY_6000_' + str(i) + '_OR_NEWER' for i in range(minor + 1)]
    if minor >= 6:
        defines.append('HTU_BACKDROP_FILTER')
    all_refs = {str(p): digest(p) for p in [*unity_refs, extension, nunit, *runners]}
    manifest['sdkProfiles'][version] = {'defines': defines, 'referenceHashes': all_refs,
                                      'precompiledDependencyQualification': 'Neo.Extensions and TestRunner binaries reused, not rebuilt for this SDK'}
    for group in ['Runtime', 'Editor', 'Tests']:
        directory = TASK / version / group
        directory.mkdir(parents=True)
        project = ET.Element('Project', Sdk='Microsoft.NET.Sdk')
        props = ET.SubElement(project, 'PropertyGroup')
        settings = {'TargetFramework': 'netstandard2.1', 'LangVersion': '9.0', 'ImplicitUsings': 'disable',
                    'EnableDefaultCompileItems': 'false', 'UseSharedCompilation': 'false', 'BuildInParallel': 'false',
                    'NuGetAudit': 'false', 'DefineConstants': ';'.join(defines), 'NoWarn': '1701;1702',
                    'AssemblyName': {'Runtime': 'Neo.HtmlToUitk.Runtime', 'Editor': 'Neo.HtmlToUitk.Editor', 'Tests': 'Neo.HtmlToUitk.Tests.Editor'}[group]}
        for name, value in settings.items():
            ET.SubElement(props, name).text = value
        items = ET.SubElement(project, 'ItemGroup')
        for path in copies[group]:
            ET.SubElement(items, 'Compile', Include=str(path))
        refs = [*unity_refs, extension]
        if group == 'Tests':
            refs += [nunit, *runners]
        for path in refs:
            ref = ET.SubElement(items, 'Reference', Include=path.stem)
            ET.SubElement(ref, 'HintPath').text = str(path)
            ET.SubElement(ref, 'Private').text = 'false'
        if group != 'Runtime':
            ET.SubElement(items, 'ProjectReference', Include='../Runtime/Runtime.csproj')
        if group == 'Tests':
            ET.SubElement(items, 'ProjectReference', Include='../Editor/Editor.csproj')
        ET.indent(project)
        ET.ElementTree(project).write(directory / (group + '.csproj'), encoding='utf-8', xml_declaration=True)

(TASK / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('Prepared isolated API-only projects:', {k: len(v) for k, v in groups.items()}, 'for both SDK profiles; no compiler or Unity launched')
