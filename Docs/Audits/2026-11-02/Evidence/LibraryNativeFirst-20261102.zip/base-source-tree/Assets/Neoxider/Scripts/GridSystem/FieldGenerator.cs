﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Neo.GridSystem
{
    /// <summary>
    ///     Generates and manages a runtime grid field with shape, state and pathfinding helpers.
    /// </summary>
    [NeoDoc("GridSystem/FieldGenerator.md")]
    [RequireComponent(typeof(Grid))]
    [CreateFromMenu("Neoxider/GridSystem/FieldGenerator")]
    [AddComponentMenu("Neoxider/" + "GridSystem/" + nameof(FieldGenerator))]
    public class FieldGenerator : MonoBehaviour
    {
        [Header("Settings")] public FieldGeneratorConfig Config = new();

        [Header("Debug")] public bool DebugEnabled = true;
        public FieldGizmoSettings GizmoSettings = new();

        /// <summary>
        ///     Invoked after field generation is completed.
        /// </summary>
        public UnityEvent OnFieldGenerated = new();

        /// <summary>
        ///     Invoked when legacy cell data is changed via <see cref="SetCell(Vector3Int,int,bool)" />.
        /// </summary>
        public CellChangedEvent OnCellChanged = new();

        /// <summary>
        ///     Invoked when cell runtime state is changed.
        /// </summary>
        public CellStateChangedEvent OnCellStateChanged = new();

        private Grid unityGrid;

        /// <summary>
        ///     Global singleton reference to the latest initialized generator.
        /// </summary>
        public static FieldGenerator I { get; private set; }

        // WHY: without this reset the next play session starts holding the previous session's destroyed
        // component when Enter Play Mode Options disable domain reload (MissingReferenceException).
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStaticState()
        {
            I = null;
        }

        /// <summary>
        ///     Backing 3D cell array.
        /// </summary>
        public FieldCell[,,] Cells { get; private set; }

        /// <summary>
        ///     Dimensions of the generated cell array, or zero before a field is available.
        ///     Changing Config.Size takes effect when GenerateField is called.
        /// </summary>
        public Vector3Int GeneratedSize => Cells != null
            ? new Vector3Int(Cells.GetLength(0), Cells.GetLength(1), Cells.GetLength(2))
            : Vector3Int.zero;

        /// <summary>
        ///     Returns a 2D projection (z=0) of the current grid.
        /// </summary>
        public FieldCell[,] Cells2D
        {
            get
            {
                Vector3Int size = GeneratedSize;
                FieldCell[,] arr = new FieldCell[size.x, size.y];
                if (Cells == null)
                {
                    return arr;
                }

                for (int x = 0; x < size.x; x++)
                for (int y = 0; y < size.y; y++)
                {
                    arr[x, y] = InBounds(new Vector3Int(x, y, 0))
                        ? Cells[x, y, 0]
                        : null;
                }

                return arr;
            }
        }

        /// <summary>
        ///     Cached Unity <see cref="Grid" /> component used for world-grid conversion.
        /// </summary>
        public Grid UnityGrid
        {
            get
            {
                if (unityGrid == null)
                {
                    unityGrid = GetComponent<Grid>();
                }

                return unityGrid;
            }
        }

        private void Awake()
        {
            I = this;
            if (unityGrid == null)
            {
                unityGrid = GetComponent<Grid>();
            }

            if (Cells == null || Cells.Length == 0)
            {
                GenerateField();
            }
        }

        private void OnDestroy()
        {
            if (I == this)
            {
                I = null;
            }
        }

        private void OnValidate()
        {
            if (!Application.isPlaying)
            {
                if (unityGrid == null)
                {
                    unityGrid = GetComponent<Grid>();
                }

                GenerateField();
            }
        }

        private void OnDrawGizmos()
        {
            DrawFieldGizmos();
        }

        [Button("Regenerate Field")]
        public void RegenerateFieldButton()
        {
            GenerateField();
        }

        [Button("Apply Shape && Overrides")]
        public void ApplyShapeAndOverridesButton()
        {
            ApplyShapeMask();
            OnFieldGenerated?.Invoke();
        }

        [Button("Clear Manual Overrides")]
        public void ClearManualOverridesButton()
        {
            if (Config == null)
            {
                return;
            }

            Config.DisabledCells.Clear();
            Config.ForcedEnabledCells.Clear();
            Config.BlockedCells.Clear();
            Config.ForcedWalkableCells.Clear();

            ApplyShapeMask();
            OnFieldGenerated?.Invoke();
        }

        [Button("Set Origin Center")]
        public void SetOriginCenterButton()
        {
            if (Config == null)
            {
                return;
            }

            Config.Origin2D = GridOrigin2D.Center;
            Config.OriginDepth = GridOriginDepth.Center;
            Config.OriginOffset = Vector3Int.zero;
            GenerateField();
        }

        /// <summary>
        ///     Generates grid cells using the current or provided configuration.
        /// </summary>
        /// <param name="config">Optional config override.</param>
        public void GenerateField(FieldGeneratorConfig config = null)
        {
            if (config != null)
            {
                Config = config;
            }

            Config ??= new FieldGeneratorConfig();
            Vector3Int size = Config.Size;
            if (size.z == 0)
            {
                size.z = 1;
                if (Config != null)
                {
                    Config.Size = size;
                }
            }

            if (size.x <= 0 || size.y <= 0 || size.z < 0)
            {
                NeoDiagnostics.LogError("FieldGenerator: Invalid field size! Size: " + size);
                Cells = null;
                return;
            }

            Cells = new FieldCell[size.x, size.y, size.z];
            for (int x = 0; x < size.x; x++)
            for (int y = 0; y < size.y; y++)
            for (int z = 0; z < size.z; z++)
            {
                Vector3Int pos = new(x, y, z);
                bool enabled = ResolveCellEnabled(pos);
                Cells[x, y, z] = new FieldCell(pos, isEnabled: enabled, isWalkable: enabled);
            }

            ApplyStateOverrides();
            OnFieldGenerated?.Invoke();
        }

        /// <summary>
        ///     Reapplies current shape mask and state overrides to existing cells.
        /// </summary>
        public void ApplyShapeMask()
        {
            if (Cells == null)
            {
                return;
            }

            foreach (FieldCell cell in GetAllCells())
            {
                bool enabled = ResolveCellEnabled(cell.Position);
                cell.IsEnabled = enabled;
                if (!enabled)
                {
                    cell.IsWalkable = false;
                    cell.IsOccupied = false;
                }
            }

            ApplyStateOverrides();
        }

        /// <summary>
        ///     Gets cell by 3D position.
        /// </summary>
        /// <param name="pos">Cell coordinates.</param>
        /// <returns>Cell instance or null when out of bounds.</returns>
        public FieldCell GetCell(Vector3Int pos)
        {
            if (Cells == null)
            {
                return null;
            }

            if (InBounds(pos))
            {
                return Cells[pos.x, pos.y, pos.z];
            }

            return null;
        }

        /// <summary>
        ///     Gets cell by 2D coordinates (z=0).
        /// </summary>
        public FieldCell GetCell(int x, int y)
        {
            return GetCell(new Vector3Int(x, y, 0));
        }

        /// <summary>
        ///     Gets cell by <see cref="Vector2Int" /> (z=0).
        /// </summary>
        public FieldCell GetCell(Vector2Int pos)
        {
            return GetCell(new Vector3Int(pos.x, pos.y, 0));
        }

        /// <summary>
        ///     Gets cell from world position via Unity Grid conversion.
        /// </summary>
        /// <param name="worldPosition">World-space position.</param>
        /// <returns>Cell instance or null.</returns>
        public FieldCell GetCellFromWorld(Vector3 worldPosition)
        {
            if (UnityGrid == null)
            {
                return null;
            }

            Vector3Int gridPos = UnityGrid.WorldToCell(worldPosition - GetOriginWorldCorrection());
            Vector3Int logicalPos = GridToLogicalPosition(gridPos);
            return GetCell(logicalPos);
        }

        /// <summary>
        ///     Resolves the logical cell position nearest to a world-space point using this generator's grid conversion.
        ///     Useful for drag/drop placement, cursor previews, and board picking.
        /// </summary>
        public bool TryGetCellPositionFromWorld(Vector3 worldPosition, out Vector3Int position)
        {
            FieldCell cell = GetNearestCellFromWorld(worldPosition, false);
            if (cell == null)
            {
                position = default;
                return false;
            }

            position = cell.Position;
            return true;
        }

        /// <summary>
        ///     Snaps a world-space point to the center of the nearest valid cell.
        /// </summary>
        public bool TrySnapWorldToCellCenter(Vector3 worldPosition, out Vector3 snappedWorldPosition)
        {
            FieldCell cell = GetNearestCellFromWorld(worldPosition, false);
            if (cell == null)
            {
                snappedWorldPosition = worldPosition;
                return false;
            }

            snappedWorldPosition = GetCellWorldCenter(cell.Position);
            return true;
        }

        /// <summary>
        ///     Snaps a world-space point to a cell center when possible, otherwise returns the original point.
        /// </summary>
        public Vector3 SnapWorldToCellCenter(Vector3 worldPosition)
        {
            return TrySnapWorldToCellCenter(worldPosition, out Vector3 snappedWorldPosition)
                ? snappedWorldPosition
                : worldPosition;
        }

        /// <summary>
        ///     Finds the nearest generated cell center to a world-space point.
        ///     This is intended for cursor previews, touch drag/drop and shape placement.
        /// </summary>
        public FieldCell GetNearestCellFromWorld(Vector3 worldPosition, bool includeDisabled = false)
        {
            FieldCell nearest = null;
            float nearestDistance = float.PositiveInfinity;
            foreach (FieldCell cell in GetAllCells(includeDisabled))
            {
                if (cell == null)
                {
                    continue;
                }

                float distance = (GetCellWorldCenter(cell.Position) - worldPosition).sqrMagnitude;
                if (distance < nearestDistance)
                {
                    nearestDistance = distance;
                    nearest = cell;
                }
            }

            return nearest;
        }

        /// <summary>
        ///     Checks whether a multi-cell content footprint can be placed at the anchor position.
        /// </summary>
        public bool CanPlaceContentFootprint(
            Vector3Int anchor,
            IEnumerable<GridPlacementEntry> entries,
            bool requireEnabled = true,
            bool requireWalkable = true,
            bool requireUnoccupied = true)
        {
            return ValidateContentFootprint(
                anchor,
                entries,
                requireEnabled,
                requireWalkable,
                requireUnoccupied,
                out _);
        }

        /// <summary>
        ///     Writes a multi-cell content footprint into FieldCell state.
        /// </summary>
        public GridPlacementResult PlaceContentFootprint(
            Vector3Int anchor,
            IEnumerable<GridPlacementEntry> entries,
            bool requireEnabled = true,
            bool requireWalkable = true,
            bool requireUnoccupied = true,
            bool notify = true)
        {
            GridPlacementResult result = new GridPlacementResult();
            if (!ValidateContentFootprint(
                    anchor,
                    entries,
                    requireEnabled,
                    requireWalkable,
                    requireUnoccupied,
                    out List<GridPlacementResolvedEntry> resolved))
            {
                result.FailureReason = "Footprint contains invalid cells.";
                return result;
            }

            foreach (GridPlacementResolvedEntry entry in resolved)
            {
                entry.Cell.ContentId = entry.Entry.ContentId;
                entry.Cell.IsOccupied = entry.Entry.OccupiesCell;
                result.Cells.Add(entry.Cell);
                result.Positions.Add(entry.Cell.Position);
            }

            if (notify)
            {
                foreach (FieldCell cell in result.Cells)
                {
                    OnCellStateChanged?.Invoke(cell);
                }
            }

            result.Placed = true;
            return result;
        }

        /// <summary>
        ///     Enumerates all cells in backing array.
        /// </summary>
        /// <param name="includeDisabled">Include disabled cells when true.</param>
        /// <returns>Cell sequence.</returns>
        public IEnumerable<FieldCell> GetAllCells(bool includeDisabled = true)
        {
            FieldCell[,,] cells = Cells;
            if (cells == null)
            {
                yield break;
            }

            Vector3Int size = new Vector3Int(cells.GetLength(0), cells.GetLength(1), cells.GetLength(2));
            for (int x = 0; x < size.x; x++)
            for (int y = 0; y < size.y; y++)
            for (int z = 0; z < size.z; z++)
            {
                FieldCell cell = cells[x, y, z];
                if (cell == null)
                {
                    continue;
                }

                if (!includeDisabled && !cell.IsEnabled)
                {
                    continue;
                }

                yield return cell;
            }
        }

        /// <summary>
        ///     Checks whether 3D position is inside the generated cell array.
        /// </summary>
        public bool InBounds(Vector3Int pos)
        {
            Vector3Int s = GeneratedSize;
            return pos.x >= 0 && pos.x < s.x && pos.y >= 0 && pos.y < s.y && pos.z >= 0 && pos.z < s.z;
        }

        /// <summary>
        ///     Checks whether 2D coordinates (z=0) are inside configured bounds.
        /// </summary>
        public bool InBounds(int x, int y)
        {
            return InBounds(new Vector3Int(x, y, 0));
        }

        /// <summary>
        ///     Checks whether 2D vector (z=0) is inside configured bounds.
        /// </summary>
        public bool InBounds(Vector2Int pos)
        {
            return InBounds(new Vector3Int(pos.x, pos.y, 0));
        }

        /// <summary>
        ///     Sets legacy cell type and walkability.
        /// </summary>
        /// <param name="pos">Target position.</param>
        /// <param name="type">Custom type id.</param>
        /// <param name="isWalkable">Walkability state.</param>
        public void SetCell(Vector3Int pos, int type, bool isWalkable)
        {
            FieldCell cell = GetCell(pos);
            if (cell == null)
            {
                return;
            }

            cell.Type = type;
            cell.IsWalkable = isWalkable;
            OnCellChanged?.Invoke(cell);
            OnCellStateChanged?.Invoke(cell);
        }

        /// <summary>
        ///     Sets legacy cell type and walkability using 2D coordinates.
        /// </summary>
        public void SetCell(int x, int y, int type, bool isWalkable)
        {
            SetCell(new Vector3Int(x, y, 0), type, isWalkable);
        }

        /// <summary>
        ///     Sets legacy cell type and walkability using 2D vector.
        /// </summary>
        public void SetCell(Vector2Int pos, int type, bool isWalkable)
        {
            SetCell(new Vector3Int(pos.x, pos.y, 0), type, isWalkable);
        }

        /// <summary>
        ///     Sets walkability for a cell.
        /// </summary>
        public void SetWalkable(Vector3Int pos, bool isWalkable)
        {
            FieldCell cell = GetCell(pos);
            if (cell == null)
            {
                return;
            }

            cell.IsWalkable = isWalkable;
            OnCellStateChanged?.Invoke(cell);
        }

        /// <summary>
        ///     Enables or disables a cell in active board shape.
        /// </summary>
        public void SetEnabled(Vector3Int pos, bool isEnabled)
        {
            FieldCell cell = GetCell(pos);
            if (cell == null)
            {
                return;
            }

            cell.IsEnabled = isEnabled;
            if (!isEnabled)
            {
                cell.IsWalkable = false;
                cell.IsOccupied = false;
            }

            OnCellStateChanged?.Invoke(cell);
        }

        /// <summary>
        ///     Marks a cell as occupied or free.
        /// </summary>
        public void SetOccupied(Vector3Int pos, bool isOccupied)
        {
            FieldCell cell = GetCell(pos);
            if (cell == null)
            {
                return;
            }

            cell.IsOccupied = isOccupied;
            OnCellStateChanged?.Invoke(cell);
        }

        /// <summary>
        ///     Sets content state id for a cell.
        /// </summary>
        public void SetContentId(Vector3Int pos, int contentId)
        {
            FieldCell cell = GetCell(pos);
            if (cell == null)
            {
                return;
            }

            cell.ContentId = contentId;
            OnCellStateChanged?.Invoke(cell);
        }

        /// <summary>
        ///     Evaluates whether cell is passable under current passability settings.
        /// </summary>
        /// <param name="cell">Cell to evaluate.</param>
        /// <param name="ignoreOccupied">Ignore occupied state if true.</param>
        /// <param name="ignoreDisabled">Ignore enabled/disabled state if true.</param>
        /// <param name="ignoreWalkability">Ignore walkability flag if true.</param>
        /// <returns>True when passable.</returns>
        public bool IsCellPassable(
            FieldCell cell,
            bool ignoreOccupied = false,
            bool ignoreDisabled = false,
            bool ignoreWalkability = false)
        {
            if (cell == null)
            {
                return false;
            }

            if (!ignoreDisabled && !cell.IsEnabled)
            {
                return false;
            }

            if (!ignoreWalkability && !cell.IsWalkable)
            {
                return false;
            }

            bool checkOccupied = Config == null ||
                                 Config.PassabilityMode == CellPassabilityMode.WalkableEnabledAndUnoccupied;
            if (checkOccupied && !ignoreOccupied && cell.IsOccupied)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Returns neighbor cells for a source cell.
        /// </summary>
        /// <param name="cell">Source cell.</param>
        /// <param name="directions">Optional movement rule override.</param>
        /// <returns>Neighbor list.</returns>
        public List<FieldCell> GetNeighbors(FieldCell cell, IEnumerable<Vector3Int> directions = null)
        {
            List<FieldCell> neighbors = new();
            if (cell == null || Config == null)
            {
                return neighbors;
            }

            IEnumerable<Vector3Int> dirs =
                directions ?? (Config.MovementRule != null ? Config.MovementRule.Directions : null);
            if (dirs == null)
            {
                return neighbors;
            }

            foreach (Vector3Int dir in dirs)
            {
                Vector3Int np = cell.Position + dir;
                FieldCell ncell = GetCell(np);
                if (ncell != null)
                {
                    neighbors.Add(ncell);
                }
            }

            return neighbors;
        }

        /// <summary>
        ///     Returns neighbors for cell position.
        /// </summary>
        public List<FieldCell> GetNeighbors(Vector3Int pos, IEnumerable<Vector3Int> directions = null)
        {
            return GetNeighbors(GetCell(pos), directions);
        }

        /// <summary>
        ///     Returns neighbors for 2D coordinates.
        /// </summary>
        public List<FieldCell> GetNeighbors(int x, int y, IEnumerable<Vector3Int> directions = null)
        {
            return GetNeighbors(new Vector3Int(x, y, 0), directions);
        }

        /// <summary>
        ///     Returns neighbors for 2D vector.
        /// </summary>
        public List<FieldCell> GetNeighbors(Vector2Int pos, IEnumerable<Vector3Int> directions = null)
        {
            return GetNeighbors(new Vector3Int(pos.x, pos.y, 0), directions);
        }

        /// <summary>
        ///     Finds a path from start to end using current passability settings.
        /// </summary>
        /// <param name="start">Start position.</param>
        /// <param name="end">End position.</param>
        /// <param name="directions">Optional movement rule override.</param>
        /// <returns>Path cells, or an empty list when no path exists.</returns>
        public List<FieldCell> FindPath(Vector3Int start, Vector3Int end, IEnumerable<Vector3Int> directions = null)
        {
            GridPathRequest request = new()
            {
                Start = start,
                End = end,
                Directions = directions
            };

            GridPathResult result = GridPathfinder.FindPath(this, request);
            return result.Path;
        }

        /// <summary>
        ///     Finds path using cell references.
        /// </summary>
        public List<FieldCell> FindPath(FieldCell start, FieldCell end, IEnumerable<Vector3Int> directions = null)
        {
            return start != null && end != null
                ? FindPath(start.Position, end.Position, directions)
                : new List<FieldCell>();
        }

        /// <summary>
        ///     Finds path using 2D coordinates.
        /// </summary>
        public List<FieldCell> FindPath(Vector2Int start, Vector2Int end, IEnumerable<Vector3Int> directions = null)
        {
            return FindPath(new Vector3Int(start.x, start.y, 0), new Vector3Int(end.x, end.y, 0), directions);
        }

        /// <summary>
        ///     Finds a path and returns detailed reason metadata.
        /// </summary>
        public GridPathResult FindPathDetailed(GridPathRequest request)
        {
            return GridPathfinder.FindPath(this, request);
        }

        /// <summary>
        ///     Finds a path with direct request arguments and diagnostic output.
        /// </summary>
        public GridPathResult FindPathDetailed(
            Vector3Int start,
            Vector3Int end,
            IEnumerable<Vector3Int> directions = null,
            bool ignoreOccupied = false,
            bool ignoreDisabled = false,
            bool ignoreWalkability = false)
        {
            GridPathRequest request = new()
            {
                Start = start,
                End = end,
                Directions = directions,
                IgnoreOccupied = ignoreOccupied,
                IgnoreDisabled = ignoreDisabled,
                IgnoreWalkability = ignoreWalkability
            };

            return FindPathDetailed(request);
        }

        /// <summary>
        ///     Converts logical cell coordinates to Unity Grid coordinates with configured origin.
        /// </summary>
        /// <param name="logicalPos">Logical coordinates in field array space.</param>
        /// <returns>Unity Grid cell coordinates.</returns>
        public Vector3Int LogicalToGridPosition(Vector3Int logicalPos)
        {
            return logicalPos + GetGridOriginOffset();
        }

        /// <summary>
        ///     Converts Unity Grid coordinates to logical field coordinates.
        /// </summary>
        /// <param name="gridPos">Unity Grid cell coordinates.</param>
        /// <returns>Logical field coordinates.</returns>
        public Vector3Int GridToLogicalPosition(Vector3Int gridPos)
        {
            return gridPos - GetGridOriginOffset();
        }

        /// <summary>
        ///     Returns world position of cell center.
        /// </summary>
        /// <param name="cellPos">Cell coordinates.</param>
        /// <returns>World-space center point.</returns>
        public Vector3 GetCellWorldCenter(Vector3Int cellPos)
        {
            if (UnityGrid == null)
            {
                return Vector3.zero;
            }

            Vector3Int gridPos = LogicalToGridPosition(cellPos);
            return UnityGrid.GetCellCenterWorld(gridPos) + GetOriginWorldCorrection();
        }

        /// <summary>
        ///     Returns world-space cell corner position.
        /// </summary>
        public Vector3 GetCellCornerWorld(Vector3Int cellPos)
        {
            if (UnityGrid == null)
            {
                return Vector3.zero;
            }

            Vector3Int gridPos = LogicalToGridPosition(cellPos);
            return UnityGrid.CellToWorld(gridPos) + GetOriginWorldCorrection();
        }

        /// <summary>
        ///     Returns world-space cell corner position for 2D coordinates.
        /// </summary>
        public Vector3 GetCellCornerWorld(Vector2Int cellPos)
        {
            return GetCellCornerWorld(new Vector3Int(cellPos.x, cellPos.y, 0));
        }

        internal static bool TryAddCoordinates(Vector3Int anchor, Vector3Int offset, out Vector3Int position)
        {
            // Widen before addition: two invalid Int32 coordinates can otherwise wrap into a valid cell.
            long x = (long)anchor.x + offset.x;
            long y = (long)anchor.y + offset.y;
            long z = (long)anchor.z + offset.z;
            if (x < int.MinValue || x > int.MaxValue ||
                y < int.MinValue || y > int.MaxValue ||
                z < int.MinValue || z > int.MaxValue)
            {
                position = default;
                return false;
            }

            position = new Vector3Int((int)x, (int)y, (int)z);
            return true;
        }

        private bool ValidateContentFootprint(
            Vector3Int anchor,
            IEnumerable<GridPlacementEntry> entries,
            bool requireEnabled,
            bool requireWalkable,
            bool requireUnoccupied,
            out List<GridPlacementResolvedEntry> resolved)
        {
            resolved = new List<GridPlacementResolvedEntry>();
            if (entries == null)
            {
                return false;
            }

            HashSet<Vector3Int> occupiedPositions = new HashSet<Vector3Int>();
            foreach (GridPlacementEntry entry in entries)
            {
                if (entry == null)
                {
                    return false;
                }

                if (!TryAddCoordinates(anchor, entry.Offset, out Vector3Int position))
                {
                    return false;
                }

                if (!occupiedPositions.Add(position))
                {
                    return false;
                }

                FieldCell cell = GetCell(position);
                if (cell == null)
                {
                    return false;
                }

                if (requireEnabled && !cell.IsEnabled)
                {
                    return false;
                }

                if (requireWalkable && !cell.IsWalkable)
                {
                    return false;
                }

                if (requireUnoccupied && cell.IsOccupied)
                {
                    return false;
                }

                resolved.Add(new GridPlacementResolvedEntry(entry, cell));
            }

            return resolved.Count > 0;
        }

        private void DrawFieldGizmos()
        {
            FieldGizmoSettings settings = GizmoSettings;
            if (!DebugEnabled || settings == null || !settings.DrawGizmos || Cells == null || Config == null ||
                UnityGrid == null)
            {
                return;
            }

            Vector3Int size = GeneratedSize;
            if (settings.DrawGrid)
            {
                Gizmos.color = settings.GridColor;
                for (int x = 0; x <= size.x; x++)
                {
                    Vector3 from = GetCellCornerWorld(new Vector3Int(x, 0, 0));
                    Vector3 to = GetCellCornerWorld(new Vector3Int(x, size.y, 0));
                    Gizmos.DrawLine(from, to);
                }

                for (int y = 0; y <= size.y; y++)
                {
                    Vector3 from = GetCellCornerWorld(new Vector3Int(0, y, 0));
                    Vector3 to = GetCellCornerWorld(new Vector3Int(size.x, y, 0));
                    Gizmos.DrawLine(from, to);
                }
            }

            if (settings.DrawCells)
            {
                Vector3 fillSize = UnityGrid.cellSize * Mathf.Clamp01(settings.CellFillScale);
#if UNITY_EDITOR
                GUIStyle coordinateStyle = null;
                if (settings.DrawCoordinates)
                {
                    coordinateStyle = new GUIStyle
                    {
                        alignment = TextAnchor.MiddleCenter,
                        fontSize = settings.TextFontSize
                    };
                    coordinateStyle.normal.textColor = settings.TextColor;
                }
#endif
                for (int x = 0; x < size.x; x++)
                for (int y = 0; y < size.y; y++)
                for (int z = 0; z < size.z; z++)
                {
                    FieldCell cell = Cells[x, y, z];
                    if (cell == null)
                    {
                        continue;
                    }

                    Vector3 pos = GetCellWorldCenter(cell.Position);
                    Gizmos.color = ResolveGizmoCellColor(cell, settings);
                    Gizmos.DrawCube(pos, fillSize);

#if UNITY_EDITOR
                    if (settings.DrawCoordinates)
                    {
                        Handles.Label(pos, $"x:{cell.Position.x} y:{cell.Position.y} z:{cell.Position.z}", coordinateStyle);
                    }
#endif
                }
            }

            if (settings.DrawPath && settings.DebugPath != null && settings.DebugPath.Count > 1)
            {
                Gizmos.color = settings.PathColor;
                for (int i = 1; i < settings.DebugPath.Count; i++)
                {
                    Vector3 a = GetCellWorldCenter(settings.DebugPath[i - 1]);
                    Vector3 b = GetCellWorldCenter(settings.DebugPath[i]);
                    Gizmos.DrawLine(a, b);
                }
            }
        }

        private static Color ResolveGizmoCellColor(FieldCell cell, FieldGizmoSettings settings)
        {
            if (!cell.IsEnabled)
            {
                return settings.DisabledCellColor;
            }

            if (cell.IsOccupied)
            {
                return settings.OccupiedCellColor;
            }

            return cell.IsWalkable ? settings.WalkableCellColor : settings.BlockedCellColor;
        }

        private bool ResolveCellEnabled(Vector3Int pos)
        {
            bool enabled = ResolveBaseShapeEnabled(pos);
            GridShapeMask shapeMask = Config != null ? Config.ShapeMask : null;
            if (shapeMask != null)
            {
                enabled = shapeMask.EvaluateCell(enabled, pos, Config.GridType);
            }

            return enabled;
        }

        private bool ResolveBaseShapeEnabled(Vector3Int pos)
        {
            if (Config == null)
            {
                return true;
            }

            switch (Config.GridType)
            {
                case GridType.Rectangular:
                    return true;
                case GridType.Custom:
                    return false;
                case GridType.Hexagonal:
                {
                    Vector3Int size = GeneratedSize;
                    int radius = Mathf.Max(1, Mathf.Min(size.x, size.y) / 2);
                    int q = pos.x - size.x / 2;
                    int r = pos.y - size.y / 2;
                    return Mathf.Abs(q) + Mathf.Abs(r) + Mathf.Abs(q + r) <= radius * 2;
                }
                default:
                    return true;
            }
        }

        private void ApplyStateOverrides()
        {
            if (Config == null)
            {
                return;
            }

            foreach (Vector3Int pos in Config.DisabledCells)
            {
                FieldCell cell = GetCell(pos);
                if (cell == null)
                {
                    continue;
                }

                cell.IsEnabled = false;
                cell.IsWalkable = false;
                cell.IsOccupied = false;
            }

            foreach (Vector3Int pos in Config.ForcedEnabledCells)
            {
                FieldCell cell = GetCell(pos);
                if (cell == null)
                {
                    continue;
                }

                cell.IsEnabled = true;
            }

            foreach (Vector3Int pos in Config.BlockedCells)
            {
                FieldCell cell = GetCell(pos);
                if (cell == null)
                {
                    continue;
                }

                cell.IsWalkable = false;
            }

            foreach (Vector3Int pos in Config.ForcedWalkableCells)
            {
                FieldCell cell = GetCell(pos);
                if (cell == null)
                {
                    continue;
                }

                if (cell.IsEnabled)
                {
                    cell.IsWalkable = true;
                }
            }
        }

        private Vector3Int GetGridOriginOffset()
        {
            if (Config == null)
            {
                return Vector3Int.zero;
            }

            Vector3Int size = GeneratedSize;
            int offsetX = GetAxisOffset(size.x, GetOriginX());
            int offsetY = GetAxisOffset(size.y, GetOriginY());
            int offsetZ = GetAxisOffset(size.z, GetOriginZ());

            return new Vector3Int(offsetX, offsetY, offsetZ) + Config.OriginOffset;
        }

        private Vector3 GetOriginWorldCorrection()
        {
            if (Config == null || UnityGrid == null)
            {
                return Vector3.zero;
            }

            Vector3Int size = GeneratedSize;
            Vector3 localCorrection = new Vector3(
                GetCenterAxisCorrection(size.x, GetOriginX()) * UnityGrid.cellSize.x,
                GetCenterAxisCorrection(size.y, GetOriginY()) * UnityGrid.cellSize.y,
                GetCenterAxisCorrection(size.z, GetOriginZ()) * UnityGrid.cellSize.z);

            return UnityGrid.transform.TransformVector(localCorrection);
        }

        private static float GetCenterAxisCorrection(int size, int anchor)
        {
            return anchor == 0 && size > 0 && size % 2 != 0 ? -0.5f : 0f;
        }

        private int GetAxisOffset(int size, int anchor)
        {
            if (size <= 0)
            {
                return 0;
            }

            switch (anchor)
            {
                case -1:
                    return 0;
                case 0:
                    return -(size / 2);
                case 1:
                    return -(size - 1);
                default:
                    return 0;
            }
        }

        private int GetOriginX()
        {
            if (Config == null)
            {
                return 0;
            }

            switch (Config.Origin2D)
            {
                case GridOrigin2D.BottomLeft:
                case GridOrigin2D.MiddleLeft:
                case GridOrigin2D.TopLeft:
                    return -1;
                case GridOrigin2D.BottomCenter:
                case GridOrigin2D.Center:
                case GridOrigin2D.TopCenter:
                    return 0;
                case GridOrigin2D.BottomRight:
                case GridOrigin2D.MiddleRight:
                case GridOrigin2D.TopRight:
                    return 1;
                default:
                    return 0;
            }
        }

        private int GetOriginY()
        {
            if (Config == null)
            {
                return 0;
            }

            switch (Config.Origin2D)
            {
                case GridOrigin2D.BottomLeft:
                case GridOrigin2D.BottomCenter:
                case GridOrigin2D.BottomRight:
                    return -1;
                case GridOrigin2D.MiddleLeft:
                case GridOrigin2D.Center:
                case GridOrigin2D.MiddleRight:
                    return 0;
                case GridOrigin2D.TopLeft:
                case GridOrigin2D.TopCenter:
                case GridOrigin2D.TopRight:
                    return 1;
                default:
                    return 0;
            }
        }

        private int GetOriginZ()
        {
            if (Config == null)
            {
                return 0;
            }

            switch (Config.OriginDepth)
            {
                case GridOriginDepth.Front:
                    return -1;
                case GridOriginDepth.Center:
                    return 0;
                case GridOriginDepth.Back:
                    return 1;
                default:
                    return 0;
            }
        }

        /// <summary>
        ///     UnityEvent wrapper carrying changed <see cref="FieldCell" />.
        /// </summary>
        [Serializable]
        public class CellChangedEvent : UnityEvent<FieldCell>
        {
        }

        /// <summary>
        ///     UnityEvent wrapper for cell state changes.
        /// </summary>
        [Serializable]
        public class CellStateChangedEvent : UnityEvent<FieldCell>
        {
        }

        private readonly struct GridPlacementResolvedEntry
        {
            public readonly GridPlacementEntry Entry;
            public readonly FieldCell Cell;

            public GridPlacementResolvedEntry(GridPlacementEntry entry, FieldCell cell)
            {
                Entry = entry;
                Cell = cell;
            }
        }
    }
}
