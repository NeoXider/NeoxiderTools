using Neo.Core.Level;
using Neo.Progression;
using Neo.Samples.Survivor;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Neo.Samples
{
    /// <summary>
    ///     Demo UI for the LevelComponent + LevelCurveDefinition system, built at runtime with uGUI
    ///     through <see cref="NeoDemoShell" /> (no prefabs, no IMGUI). Shows level, XP, XP-to-next,
    ///     an XP progress bar, and provides buttons for adding XP and resetting progress.
    /// </summary>
    public class ProgressionDemoUI : MonoBehaviour
    {
        private static readonly Color Accent = new Color(0.26f, 0.85f, 0.64f);
        private static readonly Color LevelYellow = new Color(1f, 0.84f, 0.35f);

        [Header("References")] [SerializeField]
        private LevelComponent _levelComponent;

        [Header("Settings")] [SerializeField] private int _xpPerClick = 25;

        private NeoDemoShell.Context _shell;
        private TMP_Text _levelBig;
        private TMP_Text _totalXpValue;
        private TMP_Text _toNextValue;
        private TMP_Text _currentLevelXpValue;
        private Image _xpFill;
        private GameObject _currentLevelXpRow;
        private GameObject _xpBarRow;

        private ProgressionManager _progression;
        private ProgressionNoCodeAction _progressionNoCode;
        private TMP_Text _perkPointsValue;

        private void OnEnable() => _shell?.SetVisible(true);
        private void OnDisable() => _shell?.SetVisible(false);

        private void Start()
        {
            if (_levelComponent == null)
            {
                _levelComponent = FindFirstObjectByType<LevelComponent>();
            }

            // WHY: the shell header is single-line; a long title wraps onto the overline text.
            _shell = NeoDemoShell.Build("Neo.Level Progression", Accent, transform);
            NeoDemoShell.ShowInfoCardOnce(
                "Progression (Level System)",
                "LevelComponent turns XP into levels via a LevelCurveDefinition curve.",
                "XP buttons call LevelComponent.AddXp(amount)",
                "OnLevelUp / OnXpGained events drive the readout and log",
                "Reset Progress restores the starting level and XP");

            if (_levelComponent == null)
            {
                TMP_Text status = _shell.AddValueLabel("Status");
                status.text = "No LevelComponent found in scene!";
                status.color = SurvivorUI.Danger;
                Log("<color=red>No LevelComponent found in scene!</color>");
                return;
            }

            _levelComponent.OnLevelUp.AddListener(OnLevelUp);
            _levelComponent.OnXpGained.AddListener(OnXpGained);

            BuildStatsRows();
            BuildButtonRows();
            BuildProgressionBridge();
            RefreshStats();

            Log("Progression Demo started. Use buttons below to add XP and level up!");
        }

        private void OnDestroy()
        {
            if (_levelComponent != null)
            {
                _levelComponent.OnLevelUp.RemoveListener(OnLevelUp);
                _levelComponent.OnXpGained.RemoveListener(OnXpGained);
            }

            NeoDemoShell.DestroyOwnedObject(_progressionNoCode);
            _shell?.Dispose();
        }

        private void BuildStatsRows()
        {
            _levelBig = _shell.AddBigLabel("Level 1");
            _levelBig.color = LevelYellow;

            _totalXpValue = _shell.AddValueLabel("Total XP");
            _toNextValue = _shell.AddValueLabel("XP To Next Level");

            _currentLevelXpValue = _shell.AddValueLabel("Current Level XP");
            _currentLevelXpRow = _currentLevelXpValue.transform.parent.gameObject;

            _xpFill = _shell.AddBar("XP Progress", Accent);
            // WHY: AddBar nests fill → track → row; the row is what layout shows/hides.
            _xpBarRow = _xpFill.transform.parent.parent.gameObject;
        }

        private void BuildButtonRows()
        {
            _shell.AddButtonRow(($"+ {_xpPerClick} XP", AddSmallXp));
            _shell.AddButtonRow(($"+ {_xpPerClick * 5} XP (Medium)", AddMediumXp));
            _shell.AddButtonRow(($"+ {_xpPerClick * 20} XP (Large)", AddLargeXp));

            Button[] reset = _shell.AddButtonRow(("Reset Progress", ResetLevel));
            ((Image)reset[0].targetGraphic).color = SurvivorUI.Danger;
        }

        private void BuildProgressionBridge()
        {
            // WHY: the meta-progression layer (ProgressionManager) sits on top of the LevelComponent;
            // both actions below run through the serialized ProgressionNoCodeAction bridge — no gameplay C#.
            // ProgressionManager is a self-managing Singleton — AddComponent on THIS GameObject would
            // let a duplicate's Awake Destroy the whole demo UI, so resolve it via the singleton accessor.
            _progression = ProgressionManager.I;
            _progression.AutoSave = false; // WHY: demo state must not persist into the shared default profile key
            _progression.LevelProvider = _levelComponent; // post-Awake assignment rebinds level-up rewards

            _progressionNoCode = gameObject.AddComponent<ProgressionNoCodeAction>();
            _progressionNoCode.Manager = _progression;
            _progressionNoCode.OnResultMessage.AddListener(message => Log($"NoCode: {message}"));

            _perkPointsValue = _shell.AddValueLabel("Perk Points (ProgressionManager)");

            _shell.AddButtonRow(
                ("+50 XP (NoCode)", () => RunProgressionBridge(ProgressionNoCodeActionType.AddXp, 50)),
                ("Grant 1 PP (NoCode)", () => RunProgressionBridge(ProgressionNoCodeActionType.GrantPerkPoints, 1)));
        }

        private void RunProgressionBridge(ProgressionNoCodeActionType type, int amount)
        {
            _progressionNoCode.ActionType = type;
            if (type == ProgressionNoCodeActionType.AddXp)
            {
                _progressionNoCode.XpAmount = amount;
            }
            else
            {
                _progressionNoCode.PerkPointsAmount = amount;
            }

            _progressionNoCode.Execute();
            RefreshStats();
        }

        private void AddSmallXp()
        {
            if (_levelComponent == null)
            {
                return;
            }

            _levelComponent.AddXp(_xpPerClick);
            Log($"+{_xpPerClick} XP added.");
        }

        private void AddMediumXp()
        {
            if (_levelComponent == null)
            {
                return;
            }

            int amount = _xpPerClick * 5;
            _levelComponent.AddXp(amount);
            Log($"+{amount} XP added.");
        }

        private void AddLargeXp()
        {
            if (_levelComponent == null)
            {
                return;
            }

            int amount = _xpPerClick * 20;
            _levelComponent.AddXp(amount);
            Log($"+{amount} XP added.");
        }

        private void ResetLevel()
        {
            if (_levelComponent == null)
            {
                return;
            }

            _levelComponent.ResetProgress();
            Log("<color=red>Progress reset to Start values.</color>");
            RefreshStats();
        }

        private void OnLevelUp(int newLevel)
        {
            Log($"<color=yellow>LEVEL UP! You are now Level {newLevel}</color>");
            RefreshStats();
        }

        private void OnXpGained()
        {
            RefreshStats();
        }

        private void RefreshStats()
        {
            if (_levelComponent == null || _shell == null)
            {
                return;
            }

            _levelBig.text = "Level " + _levelComponent.Level;
            _totalXpValue.text = _levelComponent.TotalXp.ToString();
            _toNextValue.text = _levelComponent.XpToNextLevel.ToString();

            if (_perkPointsValue != null && _progression != null)
            {
                _perkPointsValue.text = _progression.AvailablePerkPoints.ToString();
            }

            bool hasCurve = _levelComponent.LevelCurveDefinition != null;
            _currentLevelXpRow.SetActive(hasCurve);
            _xpBarRow.SetActive(hasCurve);
            if (hasCurve)
            {
                XpProgressSnapshot progressSnapshot = GetXpProgressSnapshot(_levelComponent);
                _currentLevelXpValue.text =
                    $"{progressSnapshot.CurrentLevelXp} / {progressSnapshot.RequiredForCurrentLevel}";
                SurvivorUI.SetFill(_xpFill, progressSnapshot.Progress01);
            }
        }

        private void Log(string msg)
        {
            _shell?.Log($"[{Time.time:F1}] {msg}");
        }

        private static XpProgressSnapshot GetXpProgressSnapshot(LevelComponent levelComponent)
        {
            Neo.Core.Level.LevelCurveDefinition curve = levelComponent.LevelCurveDefinition;
            int currentLevelRequired = curve.GetRequiredXpForLevel(levelComponent.Level);
            int nextLevelRequired = curve.GetRequiredXpForLevel(levelComponent.Level + 1);
            int currentLevelXp = Mathf.Max(0, levelComponent.TotalXp - currentLevelRequired);
            int requiredForCurrentLevel = nextLevelRequired > currentLevelRequired
                ? nextLevelRequired - currentLevelRequired
                : currentLevelXp + Mathf.Max(0, levelComponent.XpToNextLevel);

            if (requiredForCurrentLevel <= 0)
            {
                return new XpProgressSnapshot(1f, currentLevelXp, 0);
            }

            int clampedCurrentLevelXp = Mathf.Clamp(currentLevelXp, 0, requiredForCurrentLevel);
            float progress = Mathf.Clamp01(clampedCurrentLevelXp / (float)requiredForCurrentLevel);
            return new XpProgressSnapshot(progress, clampedCurrentLevelXp, requiredForCurrentLevel);
        }

        private readonly struct XpProgressSnapshot
        {
            public XpProgressSnapshot(float progress01, int currentLevelXp, int requiredForCurrentLevel)
            {
                Progress01 = progress01;
                CurrentLevelXp = currentLevelXp;
                RequiredForCurrentLevel = requiredForCurrentLevel;
            }

            public float Progress01 { get; }
            public int CurrentLevelXp { get; }
            public int RequiredForCurrentLevel { get; }
        }
    }
}
