// Standalone NUnit 4 host compatibility only. Unity keeps its existing NUnit 3 imports.
global using StringAssert = NUnit.Framework.Legacy.StringAssert;
global using CollectionAssert = NUnit.Framework.Legacy.CollectionAssert;
