﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Neo.Editor
{
    public abstract partial class CustomEditorBase
    {
        private static readonly Color ActionCardAccent = new(0.46f, 0.58f, 0.96f, 1f);
        private static readonly Color ActionButtonAccent = new(0.46f, 0.58f, 0.96f, 1f);
        private static readonly Color ActionSecondaryAccent = new(0.58f, 0.62f, 0.74f, 1f);

        private static Color ActionMetaColor => NeoInspectorTheme.MutedText;
        private static Color ActionTypeColor => NeoInspectorTheme.MutedText;

        private void DrawActionsFoldout()
        {
            if (target == null)
            {
                return;
            }

            MethodInfo[] methods = GetButtonMethods();
            if (methods.Length == 0)
            {
                return;
            }

            string key = $"{target.GetType().FullName}.NeoFoldout.Actions";
            bool current = _neoFoldouts.TryGetValue(key, out bool value) && value;

            using (new EditorGUILayout.VerticalScope())
            {
                Color accentBase = new(0.75f, 0.35f, 1f, 1f);
                var accentDark = Color.Lerp(accentBase, Color.black, 0.45f);
                Color accent = current ? accentDark : accentBase;

                current = DrawNeoSectionHeader(current, "Actions", methods.Length, accent, "d_PlayButton",
                    current ? Color.white : accentBase);

                if (current)
                {
                    using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                    {
                        DrawMethodButtons(methods);
                    }
                }
            }

            _neoFoldouts[key] = current;
        }

        private static readonly Dictionary<MethodInfo, ButtonInfo?> s_buttonInfoCache = new();

        protected ButtonInfo? FindButtonAttribute(MethodInfo method)
        {
            if (method == null)
            {
                return null;
            }

            if (!s_buttonInfoCache.TryGetValue(method, out ButtonInfo? info))
            {
                info = ResolveButtonAttribute(method);
                s_buttonInfoCache[method] = info;
            }

            return info;
        }

        private static ButtonInfo? ResolveButtonAttribute(MethodInfo method)
        {
            object[] allAttributes = method.GetCustomAttributes(false);

            foreach (object attr in allAttributes)
            {
                if (attr == null)
                {
                    continue;
                }

                Type attrType = attr.GetType();
                string fullName = attrType.FullName;
                string typeName = attrType.Name;
                string namespaceName = attrType.Namespace;

                if (fullName == "Neo.ButtonAttribute" ||
                    (namespaceName == "Neo" && typeName == "ButtonAttribute"))
                {
                    try
                    {
                        ButtonAttribute neoAttr = attr as ButtonAttribute;
                        if (neoAttr != null)
                        {
                            return new ButtonInfo(neoAttr.ButtonName, neoAttr.Width, neoAttr.PlayModeOnly);
                        }
                    }
                    catch
                    {
                    }
                }

                if (namespaceName == "Sirenix.OdinInspector" && typeName == "ButtonAttribute")
                {
                    try
                    {
                        PropertyInfo nameProperty =
                            attrType.GetProperty("Name", BindingFlags.Public | BindingFlags.Instance);
                        if (nameProperty == null)
                        {
                            nameProperty = attrType.GetProperty("ButtonName",
                                BindingFlags.Public | BindingFlags.Instance);
                        }

                        string name = nameProperty?.GetValue(attr) as string;

                        if (string.IsNullOrEmpty(name))
                        {
                            name = null;
                        }

                        float width = 120f;
                        PropertyInfo widthProperty =
                            attrType.GetProperty("Width", BindingFlags.Public | BindingFlags.Instance);
                        if (widthProperty != null)
                        {
                            object widthValue = widthProperty.GetValue(attr);
                            if (widthValue is float f)
                            {
                                width = f;
                            }
                            else if (widthValue is int i)
                            {
                                width = i;
                            }
                        }

                        return new ButtonInfo(name, width);
                    }
                    catch
                    {
                        return new ButtonInfo(null, 120f);
                    }
                }
            }

            try
            {
                ButtonAttribute neoButtonAttribute = method.GetCustomAttribute<ButtonAttribute>();
                if (neoButtonAttribute != null)
                {
                    return new ButtonInfo(neoButtonAttribute.ButtonName, neoButtonAttribute.Width,
                        neoButtonAttribute.PlayModeOnly);
                }
            }
            catch
            {
            }

            return null;
        }

        protected virtual void DrawMethodButtons()
        {
            if (target == null)
            {
                return;
            }

            DrawMethodButtons(GetCachedMethods(target.GetType()));
        }

        protected virtual void DrawMethodButtons(MethodInfo[] methods)
        {
            if (target == null || methods == null)
            {
                return;
            }

            foreach (MethodInfo method in methods)
            {
                if (method == null)
                {
                    continue;
                }

                ButtonInfo? buttonInfo = FindButtonAttribute(method);
                if (!buttonInfo.HasValue)
                {
                    continue;
                }

                ButtonInfo buttonAttribute = buttonInfo.Value;

                ParameterInfo[] parameters = method.GetParameters();
                string buttonText = string.IsNullOrEmpty(buttonAttribute.ButtonName)
                    ? method.Name
                    : buttonAttribute.ButtonName;

                if (buttonText.Length > CustomEditorSettings.ButtonTextMaxLength)
                {
                    buttonText = buttonText.Substring(0, CustomEditorSettings.ButtonTextMaxLength - 2) + "...";
                }

                string title = ObjectNames.NicifyVariableName(buttonText);

                Rect cardRect = EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                DrawActionCardChrome(cardRect,
                    parameters.Length > 0 ? ActionCardAccent : new Color(0.46f, 0.46f, 0.52f, 1f));
                using (new EditorGUILayout.VerticalScope())
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUIStyle titleStyle = new(EditorStyles.boldLabel)
                        {
                            fontSize = 13,
                            normal = { textColor = NeoInspectorTheme.TitleText }
                        };
                        GUIStyle metaStyle = new(EditorStyles.miniBoldLabel)
                        {
                            alignment = TextAnchor.MiddleRight,
                            normal = { textColor = ActionMetaColor }
                        };

                        EditorGUILayout.LabelField(title, titleStyle);
                        GUILayout.FlexibleSpace();

                        string meta = parameters.Length > 0 ? $"{parameters.Length} params" : "No params";
                        if (method.IsStatic)
                        {
                            meta += " • static";
                        }

                        GUILayout.Label(meta, metaStyle, GUILayout.Width(110f));
                    }

                    NeoxiderEditorGUI.DrawCaption($"Method `{method.Name}`");

                    if (parameters.Length > 0)
                    {
                        string foldoutKey = $"{method}_foldout";
                        if (!_buttonFoldouts.ContainsKey(foldoutKey))
                        {
                            _buttonFoldouts[foldoutKey] = false;
                        }

                        using (new EditorGUILayout.HorizontalScope())
                        {
                            string toggleLabel = _buttonFoldouts[foldoutKey]
                                ? $"▼ Parameters ({parameters.Length})"
                                : $"▶ Parameters ({parameters.Length})";

                            if (DrawInlineActionButton(toggleLabel, ActionButtonAccent, 18f, true))
                            {
                                _buttonFoldouts[foldoutKey] = !_buttonFoldouts[foldoutKey];
                            }

                            if (_buttonFoldouts[foldoutKey] &&
                                DrawInlineActionButton("Reset", ActionSecondaryAccent, 18f, false, 60f))
                            {
                                ResetStoredButtonParameters(method, parameters);
                            }
                        }

                        if (_buttonFoldouts[foldoutKey])
                        {
                            Rect paramsRect = EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                            DrawActionCardChrome(paramsRect,
                                new Color(ActionCardAccent.r, ActionCardAccent.g, ActionCardAccent.b, 0.65f), 2f, 2f);
                            using (new EditorGUILayout.VerticalScope())
                            {
                                NeoxiderEditorGUI.DrawCaption(
                                    "Parameters keep the last entered value for the current inspector session.");

                                for (int i = 0; i < parameters.Length; i++)
                                {
                                    ParameterInfo param = parameters[i];
                                    if (param == null)
                                    {
                                        continue;
                                    }

                                    string key = $"{method}_{param.Name}";
                                    object value = GetStoredButtonParameterValue(method, param, key);

                                    EditorGUI.BeginChangeCheck();
                                    object newValue = DrawParameterField(param.Name, value, param.ParameterType);
                                    if (EditorGUI.EndChangeCheck())
                                    {
                                        _buttonParameterValues[key] = newValue;
                                        _isFirstRun[key] = false;
                                    }
                                }
                            }

                            EditorGUILayout.EndVertical();
                        }
                    }

                    EditorGUILayout.Space(3f);

                    bool buttonPressed;
                    using (new EditorGUI.DisabledScope(!IsButtonEnabled(buttonAttribute.PlayModeOnly,
                               EditorApplication.isPlaying)))
                    {
                        buttonPressed = DrawGradientButton(title, 0f, 22f);
                    }

                    if (buttonPressed)
                    {
                        InvokeButtonMethod(method, parameters);
                    }
                }

                EditorGUILayout.EndVertical();

                GUILayout.Space(6f);
            }
        }

        protected object DrawParameterField(string label, object value, Type type)
        {
            try
            {
                Rect rowRect = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight + 4f);
                if (Event.current.type == EventType.Repaint)
                {
                    NeoInspectorTheme.DrawRoundedRect(rowRect, NeoInspectorTheme.RowTint, NeoInspectorTheme.RadiusRow);
                    NeoInspectorTheme.DrawAccentRail(rowRect, ActionCardAccent, 2f, 3f);
                }

                Rect contentRect = new(rowRect.x + 8f, rowRect.y + 2f, rowRect.width - 14f,
                    EditorGUIUtility.singleLineHeight);
                Rect labelRect = new(contentRect.x, contentRect.y, 126f, contentRect.height);
                Rect typeRect = new(contentRect.xMax - 70f, contentRect.y, 70f, contentRect.height);
                Rect fieldRect = new(labelRect.xMax + 8f, contentRect.y, typeRect.x - labelRect.xMax - 14f,
                    contentRect.height);

                GUIStyle titleStyle = new(EditorStyles.miniBoldLabel)
                {
                    alignment = TextAnchor.MiddleLeft,
                    normal = { textColor = NeoInspectorTheme.TitleText }
                };
                GUIStyle typeStyle = new(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleRight,
                    normal = { textColor = ActionTypeColor }
                };

                GUI.Label(labelRect, ObjectNames.NicifyVariableName(label), titleStyle);
                GUI.Label(typeRect, type.Name, typeStyle);

                object result;
                if (type == typeof(int))
                {
                    result = EditorGUI.IntField(fieldRect, value is int intValue ? intValue : 0);
                }
                else if (type == typeof(float))
                {
                    result = EditorGUI.FloatField(fieldRect, value is float floatValue ? floatValue : 0f);
                }
                else if (type == typeof(string))
                {
                    result = EditorGUI.TextField(fieldRect, value as string ?? string.Empty);
                }
                else if (type == typeof(bool))
                {
                    result = EditorGUI.Toggle(fieldRect, value is bool boolValue && boolValue);
                }
                else if (typeof(Object).IsAssignableFrom(type))
                {
                    result = EditorGUI.ObjectField(fieldRect, value as Object, type, true);
                }
                else if (type.IsEnum)
                {
                    if (value == null || !type.IsInstanceOfType(value))
                    {
                        value = Enum.GetValues(type).GetValue(0);
                    }

                    result = EditorGUI.EnumPopup(fieldRect, (Enum)value);
                }
                else if (type == typeof(Vector2))
                {
                    result = EditorGUI.Vector2Field(fieldRect, GUIContent.none,
                        value is Vector2 vector2Value ? vector2Value : Vector2.zero);
                }
                else if (type == typeof(Vector3))
                {
                    result = EditorGUI.Vector3Field(fieldRect, GUIContent.none,
                        value is Vector3 vector3Value ? vector3Value : Vector3.zero);
                }
                else if (type == typeof(Color))
                {
                    result = EditorGUI.ColorField(fieldRect, GUIContent.none,
                        value is Color colorValue ? colorValue : Color.white);
                }
                else
                {
                    EditorGUI.LabelField(fieldRect, "Unsupported");
                    result = value;
                }

                return result;
            }
            catch (InvalidCastException)
            {
                Debug.LogError($"Invalid cast for parameter {label} of type {type.Name}. Resetting to default value.");
                return GetDefaultValue(type);
            }
        }

        internal static bool IsButtonEnabled(bool playModeOnly, bool isPlaying)
        {
            return !playModeOnly || isPlaying;
        }

        private static void DrawActionCardChrome(Rect rect, Color accent, float topStripeHeight = 3f,
            float leftStripeWidth = 3f)
        {
            if (Event.current.type != EventType.Repaint)
            {
                return;
            }

            NeoInspectorTheme.DrawRoundedRect(rect, NeoInspectorTheme.PanelBackground,
                new Color(accent.r, accent.g, accent.b, 0.28f), NeoInspectorTheme.RadiusCard, 1f);
            NeoInspectorTheme.DrawAccentRail(rect, accent, leftStripeWidth, 5f);
        }

        private static bool DrawInlineActionButton(string text, Color accent, float height, bool expandWidth,
            float fixedWidth = 0f)
        {
            GUIContent content = new(text);
            Rect rect = fixedWidth > 0f
                ? GUILayoutUtility.GetRect(content, EditorStyles.miniButton, GUILayout.Width(fixedWidth),
                    GUILayout.Height(height))
                : GUILayoutUtility.GetRect(content, EditorStyles.miniButton, GUILayout.Height(height),
                    expandWidth ? GUILayout.ExpandWidth(true) : GUILayout.MinWidth(90f));

            bool isHover = rect.Contains(Event.current.mousePosition);
            if (Event.current.type == EventType.Repaint)
            {
                var bg = new Color(accent.r, accent.g, accent.b, isHover ? 0.30f : 0.20f);
                NeoInspectorTheme.DrawRoundedRect(rect, bg,
                    new Color(accent.r, accent.g, accent.b, isHover ? 0.55f : 0.35f), NeoInspectorTheme.RadiusRow, 1f);

                GUIStyle style = new(EditorStyles.miniBoldLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = NeoInspectorTheme.IsDark ? Color.Lerp(Color.white, accent, 0.10f) : Color.Lerp(accent, Color.black, 0.35f) }
                };
                style.Draw(rect, content, false, false, false, false);
            }

            return GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }

        private object GetStoredButtonParameterValue(MethodInfo method, ParameterInfo param, string key)
        {
            if (!_isFirstRun.ContainsKey(key))
            {
                _isFirstRun[key] = true;
            }

            object value;
            if (_isFirstRun[key] && param.HasDefaultValue)
            {
                value = param.DefaultValue;
                _buttonParameterValues[key] = value;
                _isFirstRun[key] = false;
            }
            else if (_buttonParameterValues.TryGetValue(key, out object storedValue))
            {
                value = storedValue;
            }
            else
            {
                value = GetDefaultValue(param.ParameterType);
                _buttonParameterValues[key] = value;
            }

            if (value == null && !param.ParameterType.IsValueType)
            {
                value = GetDefaultValue(param.ParameterType);
                _buttonParameterValues[key] = value;
            }

            return value;
        }

        private void ResetStoredButtonParameters(MethodInfo method, ParameterInfo[] parameters)
        {
            if (method == null || parameters == null)
            {
                return;
            }

            for (int i = 0; i < parameters.Length; i++)
            {
                ParameterInfo param = parameters[i];
                if (param == null)
                {
                    continue;
                }

                string key = $"{method}_{param.Name}";
                object value = param.HasDefaultValue ? param.DefaultValue : GetDefaultValue(param.ParameterType);
                _buttonParameterValues[key] = value;
                _isFirstRun[key] = false;
            }
        }

        internal void InvokeButtonMethod(MethodInfo method, ParameterInfo[] parameters)
        {
            try
            {
                object[] paramValues = new object[parameters.Length];
                for (int i = 0; i < parameters.Length; i++)
                {
                    ParameterInfo param = parameters[i];
                    if (param == null)
                    {
                        continue;
                    }

                    string key = $"{method}_{param.Name}";
                    paramValues[i] = GetStoredButtonParameterValue(method, param, key);
                }

                if (method.IsStatic)
                {
                    method.Invoke(null, paramValues);
                }
                else
                {
                    method.Invoke(target, paramValues);
                }
            }
            catch (Exception e)
            {
                Debug.LogError(
                    $"Error calling method {method.Name}: {e.InnerException?.Message ?? e.Message}\nStack trace: {e.InnerException?.StackTrace ?? e.StackTrace}");
            }
        }

        protected object GetDefaultValue(Type type)
        {
            if (type == typeof(int))
            {
                return 0;
            }

            if (type == typeof(float))
            {
                return 0f;
            }

            if (type == typeof(string))
            {
                return string.Empty;
            }

            if (type == typeof(bool))
            {
                return false;
            }

            if (type == typeof(Vector2))
            {
                return Vector2.zero;
            }

            if (type == typeof(Vector3))
            {
                return Vector3.zero;
            }

            if (type == typeof(Color))
            {
                return Color.white;
            }

            if (type.IsEnum)
            {
                return Enum.GetValues(type).GetValue(0);
            }

            if (type.IsValueType)
            {
                return Activator.CreateInstance(type);
            }

            return null;
        }
    }
}
