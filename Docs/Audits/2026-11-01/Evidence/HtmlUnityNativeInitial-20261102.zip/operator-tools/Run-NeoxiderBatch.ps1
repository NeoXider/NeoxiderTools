param(
    [Parameter(Mandatory=$true)][string]$RunName,
    [Parameter(Mandatory=$true)][ValidateSet('EditMode','PlayMode')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$Filter,
    [string]$Version='6000.3.14f1'
)
$ErrorActionPreference='Stop'
$project='D:\Git\NeoxiderTools'
$unity='C:\Program Files\Unity\Hub\Editor\'+$Version+'\Editor\Unity.exe'
if (-not (Test-Path -LiteralPath $unity)) { throw 'Requested installed Unity executable was not found.' }
if ($RunName -notmatch '^[a-z0-9-]+$') { throw 'RunName must be a simple task-owned name.' }
$output='D:\Temp\Neoxider-Audit-20261101\native-20261102\'+$RunName
if (Test-Path -LiteralPath $output) { throw 'Run evidence already exists; refusing overwrite.' }
foreach ($process in @(Get-CimInstance Win32_Process -Filter "Name='Unity.exe'")) {
    if ([string]$process.CommandLine -match '(?i)-projectPath\s+(?:"D:[/\\]Git[/\\]NeoxiderTools"|D:[/\\]Git[/\\]NeoxiderTools(?:\s|$))') {
        throw 'NeoxiderTools is already open in another Unity process.'
    }
}
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$headroom=[double]$memory.CommitLimit-[double]$memory.CommittedBytes
if ($headroom -lt 2.5GB) { throw 'Below2.5GiB free commit guard.' }
[System.IO.Directory]::CreateDirectory($output) | Out-Null
$prefsPath='Software\Unity Technologies\Unity Editor 5.x'
$prefKey=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($prefsPath,$false)
$prefs=@()
if ($null -ne $prefKey) {
    try {
        foreach ($name in @($prefKey.GetValueNames() | Where-Object { $_.StartsWith('Neoxider.HtmlToUitk.',[StringComparison]::Ordinal) })) {
            $prefs+=@{Name=$name;Kind=$prefKey.GetValueKind($name).ToString();Value=$prefKey.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}
        }
    } finally { $prefKey.Dispose() }
}
@{RegistryPath=$prefsPath;Values=@($prefs)} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'editorprefs-before.json') -Encoding utf8
$log=Join-Path $output 'editor.log'
$xml=Join-Path $output 'results.xml'
$arguments=@('-batchmode','-force-d3d11','-job-worker-count','1','-projectPath',$project,'-runTests','-testPlatform',$Mode,'-testFilter',$Filter,'-testResults',$xml,'-logFile',$log)
$record=[ordered]@{StartedUtc=[DateTime]::UtcNow.ToString('o');Version=$Version;Project=$project;Mode=$Mode;Filter=$Filter;Executable=$unity;Arguments=$arguments;CommitHeadroomBytes=$headroom;OtherEditorsControlled=$false;UserAuthorization='Direct owner reply: work in batch mode while VampireDota stays open';Graphics='D3D11, no nographics';SourceGate='all current writers stopped; independent source review accepted'}
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'launch.json') -Encoding utf8
$oldBatchMcp=[Environment]::GetEnvironmentVariable('UNITY_MCP_ALLOW_BATCH','Process')
try {
    # The package's HttpAutoStartHandler explicitly skips batch when this variable is empty.
    [Environment]::SetEnvironmentVariable('UNITY_MCP_ALLOW_BATCH',$null,'Process')
    $process=Start-Process -FilePath $unity -ArgumentList $arguments -PassThru -WindowStyle Hidden
} finally {
    [Environment]::SetEnvironmentVariable('UNITY_MCP_ALLOW_BATCH',$oldBatchMcp,'Process')
}
$record['ProcessId']=$process.Id
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'launch.json') -Encoding utf8
Write-Output ('Unity batch started PID '+$process.Id+'; output '+$output)
$process.WaitForExit()
$process.Refresh()
$record['FinishedUtc']=[DateTime]::UtcNow.ToString('o')
$record['ExitCode']=$process.ExitCode
$record['ResultsXmlExists']=Test-Path -LiteralPath $xml
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'launch.json') -Encoding utf8
Write-Output ('Unity batch exit '+$process.ExitCode+'; results.xml='+$record.ResultsXmlExists)
exit $process.ExitCode
