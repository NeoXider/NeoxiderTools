param([Parameter(Mandatory=$true)][string]$RunName,[switch]$AllTests)
$ErrorActionPreference='Stop'
if ($RunName -notmatch '^[a-z0-9-]+$') { throw 'Invalid owned run name.' }
$nativeRoot='D:\Temp\Neoxider-Audit-20261101\native-20261102'
$captureDirectory=Join-Path (Join-Path $nativeRoot $RunName) 'readback'
if (Test-Path -LiteralPath $captureDirectory) { throw 'Capture directory must be fresh.' }
& python 'D:\Temp\Neoxider-Audit-20261101\native_receipt.py' freeze $RunName
if ($LASTEXITCODE -ne 0) { throw 'Source freeze failed.' }
$inputDirectory=Join-Path $nativeRoot ($RunName+'-inputs')
@{RequestedUtc=[DateTime]::UtcNow.ToString('o');CaptureDirectory=$captureDirectory;CaptureSourceSHA256=(Get-FileHash -LiteralPath 'D:\Git\NeoxiderTools\Assets\HtmlToUitkShowcase\Tests\PlayMode\VeloraShowcaseInteractionTests.cs' -Algorithm SHA256).Hash;ChangedAcceptanceThresholds=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $inputDirectory 'capture-request.json') -Encoding utf8
$testFilter='VeloraShowcase.QA.VeloraShowcaseInteractionTests.DesktopHeroCta_IsPaintedReadableAndPointerOperable;VeloraShowcase.QA.VeloraShowcaseInteractionTests.MobileHeroCta_IsPaintedReadableAndPointerOperable'
if ($AllTests) { $testFilter='VeloraShowcase.QA.VeloraShowcaseInteractionTests' }
$priorCaptureDirectory=[Environment]::GetEnvironmentVariable('NEO_VELORA_CAPTURE_DIR','Process')
try {
    [Environment]::SetEnvironmentVariable('NEO_VELORA_CAPTURE_DIR',$captureDirectory,'Process')
    & 'D:\Temp\Neoxider-Audit-20261101\Run-NeoxiderBatch.ps1' -RunName $RunName -Mode PlayMode -Filter $testFilter
    $taskUnityExit=$LASTEXITCODE
} finally { [Environment]::SetEnvironmentVariable('NEO_VELORA_CAPTURE_DIR',$priorCaptureDirectory,'Process') }
exit $taskUnityExit
