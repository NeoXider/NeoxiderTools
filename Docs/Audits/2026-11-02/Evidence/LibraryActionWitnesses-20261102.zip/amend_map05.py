import copy
import datetime
import hashlib
import json
from pathlib import Path

base = Path('D:/Temp/Neoxider-LibraryClosure-20261102')
root = Path('D:/Git/NeoxiderTools')
original = base / 'acceptance-05.json'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '2fa9c64fb1879849132e9420176fb9a151de1ba877a969b90d8605f6988839d4'
data = json.loads(original.read_text(encoding='utf-8'))
relative = 'Assets/Neoxider/package.json'
frozen_path = base / 'runs/verification-inventory-u63-green-r1-inputs/sources' / relative
old = json.loads(frozen_path.read_text(encoding='utf-8'))
current = json.loads((root / relative).read_text(encoding='utf-8'))
without_descriptions = copy.deepcopy(current)
for index in range(len(old['samples'])):
    without_descriptions['samples'][index]['description'] = old['samples'][index]['description']
assert without_descriptions == old
changed_descriptions = [index for index, sample in enumerate(current['samples']) if sample['description'] != old['samples'][index]['description']]
assert changed_descriptions == [0, 1]
current_hash = hashlib.sha256((root / relative).read_bytes()).hexdigest()
entry = data['qualifiedSources'][relative]
old_hash = entry['currentSha256']
entry['capturedCurrentSha256'] = old_hash
entry['currentSha256'] = current_hash
entry['postCaptureQualification'] = 'Root later changed ONLY sample descriptions0/1; name/version/dependencies/samplepaths and all other JSON values exactly match frozen input. Frozen hashes/copies/results remain unchanged.'
for run, qualification in entry['perRun'].items():
    assert qualification['frozenManifestSha256'] == old_hash
    qualification['currentEqualsFrozenManifest'] = False
affected = []
for action in data['actions']:
    qualification = action['sourcequalification']
    if relative not in qualification['files']:
        continue
    affected.append(action['actionId'])
    qualification.setdefault('notCurrentEqualInAllTheseRuns', {})[relative] = list(qualification['witnessRuns'])
    qualification['postCapturePackageDescriptionChange'] = entry['postCaptureQualification']
assert set(affected) == {'TEST-PORTABLE-NONEMPTY-SAMPLES', 'TEST-SAMPLE-NATIVE-EVIDENCE-IDENTITIES', 'TEST-SAMPLE-GENERIC-SCENE-IDENTITY-ADMISSION', 'S3-PRIMARY-MIRROR-ABSENCE-GUARD', 'S3-PRIMARY-REMAINING-LEGACY-CONTRACTS'}
data['operatorAmendments'] = [{'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'operator': 'root', 'capturedOriginalFile': original.name, 'capturedOriginalSHA256': hashlib.sha256(original.read_bytes()).hexdigest(), 'changedCurrentPath': relative, 'capturedCurrentSHA256': old_hash, 'observedCurrentSHA256': current_hash, 'changedSampleDescriptionIndices': changed_descriptions, 'affectedActionIds': affected, 'frozenHashesOrResultsChanged': False, 'requiresNewRuntimeTestForProse': False}]
target = base / 'acceptance-05-operator-amended.json'
if target.exists():
    raise SystemExit('Operator amendment already exists; refusing overwrite')
target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'file': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'affectedActionIds': affected, 'originalPreserved': True, 'currentPackageSHA256': current_hash}))
