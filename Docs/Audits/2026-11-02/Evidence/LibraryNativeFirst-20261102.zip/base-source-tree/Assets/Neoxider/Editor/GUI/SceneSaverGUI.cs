using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Neo.Editor.Windows
{
    /// <summary>
    ///     GUI for the Scene Saver window.
    /// </summary>
    public class SceneSaverGUI : EditorWindowGUI
    {
        private readonly SceneSaverSettings _settings;
        private string _currentScenePath;
        private string _lastSaveStatus = "";

        /// <summary>Creates a GUI bound to the shared, persisted settings.</summary>
        public SceneSaverGUI() : this(SceneSaverSettings.Shared)
        {
        }

        /// <summary>Creates a GUI bound to the given settings instance.</summary>
        /// <param name="settings">Settings to read and edit; <c>null</c> falls back to the shared instance.</param>
        public SceneSaverGUI(SceneSaverSettings settings)
        {
            _settings = settings ?? SceneSaverSettings.Shared;
        }

        /// <summary>
        ///     Whether the saver script is enabled.
        /// </summary>
        public bool IsScriptEnabled => _settings.IsEnabled;

        /// <summary>
        ///     Auto-save interval in minutes.
        /// </summary>
        public float IntervalMinutes => _settings.IntervalMinutes;

        /// <summary>
        ///     Whether to save even when the scene is not dirty.
        /// </summary>
        public bool SaveEvenIfNotDirty => _settings.SaveEvenIfNotDirty;

        /// <summary>
        ///     Refreshes the active scene path.
        /// </summary>
        public void UpdateCurrentScenePath()
        {
            Scene activeScene = EditorSceneManager.GetActiveScene();
            _currentScenePath = activeScene.path;

            if (string.IsNullOrEmpty(_currentScenePath))
            {
                _currentScenePath = "Untitled";
            }
        }

        /// <summary>
        ///     Draws the window GUI.
        /// </summary>
        public override void OnGUI(EditorWindow window)
        {
            UpdateCurrentScenePath();
            Scene activeScene = EditorSceneManager.GetActiveScene();
            bool hasSavedScene = !string.IsNullOrEmpty(activeScene.path);

            NeoxiderEditorGUI.DrawSummaryCard("Scene Saver",
                "Automatically saves a backup copy of the active scene to `Assets/Scenes/AutoSaves`.",
                new NeoxiderEditorGUI.Badge(IsScriptEnabled ? "Enabled" : "Disabled",
                    IsScriptEnabled ? new Color(0.18f, 0.62f, 0.32f, 1f) : new Color(0.46f, 0.46f, 0.50f, 1f)),
                new NeoxiderEditorGUI.Badge($"Interval {IntervalMinutes:0.##} min", new Color(0.20f, 0.50f, 0.78f, 1f)),
                new NeoxiderEditorGUI.Badge(activeScene.isDirty ? "Scene Dirty" : "Scene Clean",
                    activeScene.isDirty ? new Color(0.78f, 0.46f, 0.18f, 1f) : new Color(0.24f, 0.60f, 0.60f, 1f)));

            if (!hasSavedScene)
            {
                EditorGUILayout.HelpBox(
                    "The active scene is not saved as an asset yet. Auto-save will work after the first normal Save Scene.",
                    MessageType.Info);
            }

            NeoxiderEditorGUI.BeginSection("Auto Save",
                "Basic automatic save options. Stored in EditorPrefs, so they survive an editor restart.");
            _settings.IsEnabled = EditorGUILayout.Toggle("Enable Scene Saver Script", IsScriptEnabled);
            // WHY: delayed, because a plain FloatField commits on every keystroke and the minimum clamp
            // would rewrite "0.5" to "0.25" while it is still being typed.
            _settings.IntervalMinutes = EditorGUILayout.DelayedFloatField("Interval (minutes)", IntervalMinutes);
            _settings.SaveEvenIfNotDirty = EditorGUILayout.Toggle("Save Even If Not Dirty", SaveEvenIfNotDirty);

            if (GUILayout.Button("Reset Settings"))
            {
                _settings.ResetToDefaults();
            }

            NeoxiderEditorGUI.EndSection();

            EditorGUILayout.Space(4f);

            NeoxiderEditorGUI.BeginSection("Current Scene",
                "State of the open scene and the last save result.");
            EditorGUILayout.LabelField("Current Scene", _currentScenePath);
            EditorGUILayout.LabelField("Last Save Status",
                string.IsNullOrEmpty(_lastSaveStatus) ? "No saves yet." : _lastSaveStatus);
            NeoxiderEditorGUI.EndSection();

            EditorGUILayout.Space(4f);

            EditorGUI.BeginDisabledGroup(!hasSavedScene && !activeScene.isDirty);
            if (GUILayout.Button("Save Now", GUILayout.Height(24f)))
            {
                SaveSceneClone();
            }

            EditorGUI.EndDisabledGroup();
        }

        /// <summary>
        ///     Saves a copy of the scene to the auto-save folder.
        /// </summary>
        /// <remarks>
        ///     The copy is written with <c>saveAsCopy: true</c>, which leaves the edited scene untouched —
        ///     and, importantly, still dirty. Scheduling therefore must not treat the dirty flag as "not
        ///     backed up yet"; that is <see cref="SceneSaverAutoSaveScheduler" />'s job, and this method
        ///     reports the finished attempt to it.
        /// </remarks>
        public void SaveSceneClone()
        {
            if (EditorApplication.isPlaying)
            {
                _lastSaveStatus = "Skipping auto-save in Play mode.";
                return;
            }

            Scene currentScene = EditorSceneManager.GetActiveScene();

            if (string.IsNullOrEmpty(currentScene.path))
            {
                _lastSaveStatus = "Scene not saved yet, skipping auto-save.";
                return;
            }

            if (!currentScene.isDirty && !SaveEvenIfNotDirty)
            {
                _lastSaveStatus = "Scene is not dirty, skipping auto-save.";
                return;
            }

            try
            {
                UpdateCurrentScenePath();
                bool saved = SaveSceneBackup(currentScene, out string newScenePath);

                if (saved)
                {
                    _lastSaveStatus = $"Auto-saved: {newScenePath}";
                    Debug.Log($"[SceneSaver] {_lastSaveStatus}");
                }
                else
                {
                    _lastSaveStatus = "Auto-save failed.";
                    Debug.LogWarning($"[SceneSaver] Failed to save scene to {newScenePath}");
                }
            }
            catch (Exception e)
            {
                _lastSaveStatus = $"Error: {e.Message}";
                Debug.LogError($"[SceneSaver] {e.Message}");
            }
            finally
            {
                // WHY: a manual "Save Now" counts as handling the current revision too, otherwise the
                // background check writes the identical file again a moment later.
                global::SceneSaver.MarkActiveSceneHandled();
            }
        }

        internal static string GetBackupPath(string scenePath)
        {
            string sceneGuid = AssetDatabase.AssetPathToGUID(scenePath);
            if (string.IsNullOrEmpty(sceneGuid))
            {
                throw new InvalidOperationException("The source scene must have a valid asset GUID.");
            }

            string sceneName = Path.GetFileNameWithoutExtension(scenePath);
            return $"Assets/Scenes/AutoSaves/{sceneGuid}/{sceneName}_AutoSave.unity";
        }

        // Uses the same writer as Save Now, without changing the shared scheduler/settings in addressed tests.
        internal static bool SaveSceneBackup(Scene scene, out string backupPath)
        {
            backupPath = GetBackupPath(scene.path);
            string directory = Path.GetDirectoryName(backupPath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
                AssetDatabase.Refresh();
            }

            return EditorSceneManager.SaveScene(scene, backupPath, true);
        }
    }
}
