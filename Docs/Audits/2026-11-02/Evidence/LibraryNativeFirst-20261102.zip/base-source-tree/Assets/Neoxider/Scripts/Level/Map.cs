using System;
using Neo.Save;
using UnityEngine;

namespace Neo.Level
{
        [Serializable]
        public class Map
        {
            public bool isInfinity = true;
            public int countLevels;
            public bool isLoopLevel;

            [Space] [SerializeField] private int _level;

            public int idMap;

            private string _saveKey;
            public int level => _level;

            public void Load(int i, string saveKey)
            {
                idMap = i;
                _saveKey = saveKey;

                _level = Mathf.Max(0, SaveProvider.GetInt(GetSaveKey() + nameof(_level)));
            }

            private string GetSaveKey()
            {
                return $"Map_{_saveKey}_{idMap}_";
            }

            public void SaveLevel()
            {
                if (_level == int.MaxValue)
                {
                    return;
                }

                int previousLevel = _level;
                _level++;
                try
                {
                    SaveProvider.SetInt(GetSaveKey() + nameof(_level), _level);
                }
                catch
                {
                    _level = previousLevel;
                    throw;
                }
            }

            public bool GetCopmplete()
            {
                if (!isInfinity)
                {
                    return _level >= countLevels;
                }

                return false;
            }
        }
}
