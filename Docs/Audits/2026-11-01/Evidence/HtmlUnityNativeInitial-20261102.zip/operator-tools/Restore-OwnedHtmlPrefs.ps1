param([Parameter(Mandatory=$true)][string]$RunName)
$ErrorActionPreference='Stop'
if ($RunName -notmatch '^[a-z0-9-]+$') { throw 'Invalid owned run name.' }
$output=Join-Path 'D:\Temp\Neoxider-Audit-20261101\native-20261102' $RunName
$before=Get-Content -LiteralPath (Join-Path $output 'editorprefs-before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey([string]$before.RegistryPath,$true)
if ($null -eq $key) { throw 'Expected preferences registry key missing.' }
function Snapshot($registryKey) {
    $values=@()
    foreach ($name in @($registryKey.GetValueNames() | Where-Object { $_.StartsWith('Neoxider.HtmlToUitk.',[StringComparison]::Ordinal) })) {
        $values+=@{Name=$name;Kind=$registryKey.GetValueKind($name).ToString();Value=$registryKey.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}
    }
    return ,$values
}
try {
    $after=Snapshot $key
    @{RegistryPath=$before.RegistryPath;Values=@($after)} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'editorprefs-after.json') -Encoding utf8
    foreach ($original in @($before.Values)) {
        $current=@($after | Where-Object { $_.Name -ceq $original.Name })
        if ($current.Count -ne 1 -or $current[0].Kind -cne $original.Kind -or
            (ConvertTo-Json -InputObject $current[0].Value -Compress) -cne (ConvertTo-Json -InputObject $original.Value -Compress)) {
            throw 'An existing preference differs; refusing automatic modification.'
        }
    }
    $extra=@($after | Where-Object { $_.Name -cnotin @($before.Values | ForEach-Object { $_.Name }) })
    foreach ($item in $extra) {
        # The fixture restores a previously absent CLI setting as an empty value.
        # Never delete any unknown setting or a nonempty value.
        $isOwnedCli=$item.Name -cmatch '^Neoxider\.HtmlToUitk\.cli(?:_h[0-9]+)?$'
        $isEmpty=($item.Kind -ceq 'String' -and [string]$item.Value -ceq '') -or
            ($item.Kind -ceq 'Binary' -and @($item.Value).Count -eq 1 -and [int]$item.Value[0] -eq 0)
        if (-not $isOwnedCli -or -not $isEmpty) { throw ('Unexpected newly created preference: '+$item.Name+' ('+$item.Kind+'); no deletion performed.') }
    }
    foreach ($item in $extra) { $key.DeleteValue($item.Name,$true) }
    $restored=Snapshot $key
    if (@($restored).Count -ne @($before.Values).Count) { throw 'Preference key count did not restore.' }
    foreach ($original in @($before.Values)) {
        $current=@($restored | Where-Object { $_.Name -ceq $original.Name })
        if ($current.Count -ne 1 -or $current[0].Kind -cne $original.Kind -or
            (ConvertTo-Json -InputObject $current[0].Value -Compress) -cne (ConvertTo-Json -InputObject $original.Value -Compress)) { throw 'Final preference comparison failed.' }
    }
    @{RestoredUtc=[DateTime]::UtcNow.ToString('o');OriginalCount=@($before.Values).Count;AfterCount=@($after).Count;RemovedOwnedEmptyCliCount=$extra.Count;ExactOriginalNamesKindsDataRestored=$true;PrivateValuesPublished=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'editorprefs-restoration.json') -Encoding utf8
    Write-Output ('HTML preferences restored exactly; removed task-created empty CLI keys: '+$extra.Count)
} finally { $key.Dispose() }
