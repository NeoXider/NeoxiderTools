using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Neo.Editor
{
    /// <summary>
    ///     Handles component-related functionality in the custom editor.
    ///     Provides methods for finding and assigning components based on attributes.
    /// </summary>
    public static class ComponentDrawer
    {
        private static readonly ConditionalWeakTable<MonoBehaviour, HashSet<FieldInfo>> UnmatchedSceneFields = new();

        /// <summary>
        ///     Processes all component-related attributes on the target object's fields.
        /// </summary>
        /// <param name="targetObject">The MonoBehaviour to process attributes for.</param>
        public static void ProcessComponentAttributes(MonoBehaviour targetObject)
        {
            if (!NeoxiderSettings.EnableAttributeSearch)
            {
                return;
            }

            FieldInfo[] fields = targetObject.GetType().GetFields(CustomEditorBase.FIELD_FLAGS);

            foreach (FieldInfo field in fields)
            {
                object fieldValue = field.GetValue(targetObject);
                bool isNull = fieldValue == null || (fieldValue is Object obj && obj == null);

                if (isNull)
                {
                    ProcessNullField(field, targetObject);
                }
                else if (IsEmptyCollection(fieldValue))
                {
                    ProcessEmptyCollection(field, targetObject);
                }
            }
        }

        private static void ProcessNullField(FieldInfo field, MonoBehaviour targetObject)
        {
            if (HasAttribute<FindInSceneAttribute>(field))
            {
                AssignComponentFromScene(field, targetObject);
            }
            else if (HasAttribute<FindAllInSceneAttribute>(field))
            {
                AssignAllComponentsFromScene(field, targetObject);
            }
            else if (HasAttribute<GetComponentAttribute>(field))
            {
                AssignComponentFromGameObject(field, targetObject);
            }
            else if (HasAttribute<GetComponentsAttribute>(field))
            {
                AssignComponentsFromGameObject(field, targetObject);
            }
        }

        private static void ProcessEmptyCollection(FieldInfo field, MonoBehaviour targetObject)
        {
            if (HasAttribute<GetComponentsAttribute>(field))
            {
                AssignComponentsFromGameObject(field, targetObject);
            }
            else if (HasAttribute<FindAllInSceneAttribute>(field))
            {
                AssignAllComponentsFromScene(field, targetObject);
            }
        }

        private static Object[] GetComponentsFromScene(Type componentType,
            FindObjectsSortMode sortMode = FindObjectsSortMode.None)
        {
            if (componentType == typeof(GameObject))
            {
                return CustomEditorBase.FindObjectsByType<GameObject>(sortMode);
            }

            return CustomEditorBase.FindObjectsByType(componentType, sortMode);
        }

        private static void AssignComponentFromScene(FieldInfo field, MonoBehaviour targetObject)
        {
            if (field == null || targetObject == null)
            {
                return;
            }

            Type componentType = field.FieldType;
            if (!typeof(Component).IsAssignableFrom(componentType) && componentType != typeof(GameObject))
            {
                Debug.LogWarning($"Field '{field.Name}': type {componentType} is not a Component or GameObject.");
                return;
            }

            try
            {
                Object candidate = FindCompatibleSceneCandidate(field, GetComponentsFromScene(componentType));
                HashSet<FieldInfo> unmatchedFields = UnmatchedSceneFields.GetOrCreateValue(targetObject);
                if (candidate != null)
                {
                    Undo.RecordObject(targetObject, "Find attributed component");
                    field.SetValue(targetObject, candidate);
                    EditorUtility.SetDirty(targetObject);
                    unmatchedFields.Remove(field);
                }
                else if (unmatchedFields.Add(field))
                {
                    Debug.LogWarning(
                        $"No compatible {componentType.Name} found in scene for field '{field.Name}'. " +
                        "All RequireInterface constraints must be satisfied.", targetObject);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error finding {componentType.Name} in scene: {e.Message}");
            }
        }

        internal static Object FindCompatibleSceneCandidate(FieldInfo field, Object[] candidates)
        {
            RequireInterface[] requirements = field.GetCustomAttributes<RequireInterface>(true).ToArray();
            foreach (Object candidate in candidates)
            {
                if (candidate == null)
                {
                    continue;
                }

                bool compatible = true;
                foreach (RequireInterface requirement in requirements)
                {
                    if (!RequireInterfaceDrawer.IsReferenceValid(candidate, requirement.RequireType))
                    {
                        compatible = false;
                        break;
                    }
                }

                if (compatible)
                {
                    return candidate;
                }
            }

            return null;
        }

        private static void AssignAllComponentsFromScene(FieldInfo field, MonoBehaviour targetObject)
        {
            var attribute = field.GetCustomAttributes(typeof(FindAllInSceneAttribute), false)
                .FirstOrDefault() as FindAllInSceneAttribute;
            if (attribute == null)
            {
                return;
            }

            Type elementType = GetElementType(field);
            if (elementType == null)
            {
                elementType = field.FieldType;
            }

            if (!typeof(Component).IsAssignableFrom(elementType) && elementType != typeof(GameObject))
            {
                Debug.LogWarning($"Field '{field.Name}': type {elementType} is not a Component or GameObject.");
                return;
            }

            Object[] components = GetComponentsFromScene(elementType, attribute.SortMode);
            SetFieldValueForCollection(field, targetObject, components);
        }

        private static void AssignComponentFromGameObject(FieldInfo field, MonoBehaviour targetObject)
        {
            var attribute = field.GetCustomAttributes(typeof(GetComponentAttribute), false)
                .FirstOrDefault() as GetComponentAttribute;
            if (attribute == null)
            {
                return;
            }

            Component component = attribute.SearchInChildren
                ? targetObject.GetComponentInChildren(field.FieldType)
                : targetObject.GetComponent(field.FieldType);

            if (component != null)
            {
                field.SetValue(targetObject, component);
                EditorUtility.SetDirty(targetObject);
            }
        }

        private static void AssignComponentsFromGameObject(FieldInfo field, MonoBehaviour targetObject)
        {
            var attribute = field.GetCustomAttributes(typeof(GetComponentsAttribute), false)
                .FirstOrDefault() as GetComponentsAttribute;
            if (attribute == null)
            {
                return;
            }

            Type elementType = GetElementType(field);
            if (elementType == null)
            {
                elementType = field.FieldType;
            }

            if (!typeof(Component).IsAssignableFrom(elementType) && elementType != typeof(GameObject))
            {
                Debug.LogWarning($"Field '{field.Name}': type {elementType} is not a Component or GameObject.");
                return;
            }

            if (elementType == typeof(GameObject))
            {
                GameObject[] gameObjects = attribute.SearchInChildren
                    ? targetObject.GetComponentsInChildren<Transform>().Select(t => t.gameObject).ToArray()
                    : new[] { targetObject.gameObject };
                SetFieldValueForCollection(field, targetObject, gameObjects);
                return;
            }

            Component[] components = attribute.SearchInChildren
                ? targetObject.GetComponentsInChildren(elementType)
                : targetObject.GetComponents(elementType);
            SetFieldValueForCollection(field, targetObject, components);
        }

        internal static void SetFieldValueForCollection(FieldInfo field, MonoBehaviour targetObject, Array value)
        {
            Type elementType = GetElementType(field);
            object assignment;
            if (elementType != null && field.FieldType.IsArray)
            {
                Array typedArray = Array.CreateInstance(elementType, value.Length);
                Array.Copy(value, typedArray, value.Length);
                assignment = typedArray;
            }
            else if (elementType != null)
            {
                Type listType = typeof(List<>).MakeGenericType(elementType);
                if (!field.FieldType.IsAssignableFrom(listType))
                {
                    return;
                }

                IList list = (IList)Activator.CreateInstance(listType);
                foreach (object item in value)
                {
                    list.Add(item);
                }

                assignment = list;
            }
            else if (value.Length > 0)
            {
                assignment = value.GetValue(0);
            }
            else
            {
                Debug.LogWarning(
                    $"Field '{field.Name}' is neither an array nor an IList, and no components were found.");
                return;
            }

            Undo.RecordObject(targetObject, "Assign attributed collection");
            field.SetValue(targetObject, assignment);
            EditorUtility.SetDirty(targetObject);
        }

        private static bool HasAttribute<T>(FieldInfo field) where T : Attribute
        {
            return field.GetCustomAttributes(typeof(T), false).Length > 0;
        }

        private static bool IsEmptyCollection(object value)
        {
            return (value is Array arr && arr.Length == 0) ||
                   (value is IList list && list.Count == 0);
        }

        private static Type GetElementType(FieldInfo field)
        {
            if (field.FieldType.IsArray)
            {
                return field.FieldType.GetElementType();
            }

            if (field.FieldType.IsGenericType)
            {
                Type genericType = field.FieldType.GetGenericTypeDefinition();
                if (genericType == typeof(List<>) ||
                    genericType == typeof(IList<>) ||
                    genericType == typeof(ICollection<>) ||
                    genericType == typeof(IEnumerable<>))
                {
                    Type[] args = field.FieldType.GetGenericArguments();
                    if (args.Length > 0)
                    {
                        return args[0];
                    }
                }
            }

            return null;
        }
    }
}
