using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Neo.Editor
{
    public abstract partial class CustomEditorBase
    {
        private void DrawNeoPropertiesWithCollapsibleUnityEvents()
        {
            if (serializedObject == null)
            {
                return;
            }

            serializedObject.Update();

            List<SerializedProperty> unityEvents = new();
            List<SerializedProperty> properties = new();
            SerializedProperty scriptProp = null;

            SerializedProperty iterator = serializedObject.GetIterator();
            bool enterChildren = true;
            while (iterator.NextVisible(enterChildren))
            {
                enterChildren = false;

                if (iterator.name == "m_Script")
                {
                    scriptProp = iterator.Copy();
                    continue;
                }

                if (IsUnityEventProperty(iterator))
                {
                    unityEvents.Add(iterator.Copy());
                    continue;
                }

                properties.Add(iterator.Copy());
            }

            if (scriptProp != null)
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.PropertyField(scriptProp, true);
                }
            }

            DrawHeaderSections(properties);

            if (unityEvents.Count > 0)
            {
                EditorGUILayout.Space(4);
                DrawUnityEventsFoldout(unityEvents);
            }

            DrawActionsFoldout();

            serializedObject.ApplyModifiedProperties();
        }

        private void DrawHeaderSections(List<SerializedProperty> properties)
        {
            if (properties == null || properties.Count == 0 || target == null)
            {
                return;
            }

            bool hasAnyHeader = false;
            for (int i = 0; i < properties.Count; i++)
            {
                if (!string.IsNullOrEmpty(TryGetHeaderTitleForProperty(properties[i])))
                {
                    hasAnyHeader = true;
                    break;
                }
            }

            if (!hasAnyHeader)
            {
                for (int i = 0; i < properties.Count; i++)
                {
                    DrawPropertyField(properties[i], false);
                }

                return;
            }

            List<HeaderSection> sections = BuildHeaderSections(properties);
            Color baseGreen = CustomEditorSettings.ScriptNameColor;
            var darkGreen = Color.Lerp(baseGreen, Color.black, 0.75f);
            int minFieldsForCategory = Mathf.Max(0, CustomEditorSettings.MinFieldsForHeaderCategory);

            for (int i = 0; i < sections.Count; i++)
            {
                HeaderSection section = sections[i];
                if (section.IsWarningHeader)
                {
                    DrawWarningHeader(section.Title);
                    for (int p = 0; p < section.Properties.Count; p++)
                    {
                        DrawPropertyField(section.Properties[p], true);
                    }

                    continue;
                }

                bool excludeFromMinFieldsRule =
                    string.Equals(section.Title, "Actions", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(section.Title, "Events", StringComparison.OrdinalIgnoreCase);

                bool shouldForceFoldout = ShouldForceFoldoutHeader(section);

                // WHY: the one-field shortcut has to yield to the force-foldout rule, or a section holding a
                // single list renders as a bare label while its neighbour holding a list plus two settings
                // renders as a folder - the same content styled two different ways in one inspector.
                if (!excludeFromMinFieldsRule && !shouldForceFoldout && section.Properties.Count == 1)
                {
                    DrawPlainHeader(section.Title);
                    for (int p = 0; p < section.Properties.Count; p++)
                    {
                        DrawPropertyField(section.Properties[p], true);
                    }

                    continue;
                }

                if (!excludeFromMinFieldsRule &&
                    !shouldForceFoldout &&
                    minFieldsForCategory > 0 &&
                    section.Properties.Count < minFieldsForCategory)
                {
                    DrawPlainHeader(section.Title);
                    for (int p = 0; p < section.Properties.Count; p++)
                    {
                        DrawPropertyField(section.Properties[p], true);
                    }

                    continue;
                }

                string key = $"{target.GetType().FullName}.NeoFoldout.Header.{section.Title}";
                bool expanded = GetFoldoutState(key, true);

                Color accent = expanded ? darkGreen : baseGreen;
                Color titleColor = expanded ? Color.white : baseGreen;
                expanded = DrawNeoSectionHeader(expanded, section.Title, section.Properties.Count, accent,
                    "d_Folder Icon", titleColor);
                _neoFoldouts[key] = expanded;

                if (!expanded)
                {
                    continue;
                }

                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUI.indentLevel++;
                    for (int p = 0; p < section.Properties.Count; p++)
                    {
                        DrawPropertyField(section.Properties[p], true);
                    }

                    EditorGUI.indentLevel--;
                }
            }
        }

        private static bool ShouldForceFoldoutHeader(HeaderSection section)
        {
            if (section.Properties == null || section.Properties.Count == 0)
            {
                return false;
            }

            for (int i = 0; i < section.Properties.Count; i++)
            {
                SerializedProperty property = section.Properties[i];
                if (property == null)
                {
                    continue;
                }

                if (property.isArray && property.propertyType != SerializedPropertyType.String)
                {
                    return true;
                }

                if (property.propertyType == SerializedPropertyType.Generic && property.hasVisibleChildren)
                {
                    return true;
                }
            }

            return false;
        }

        private void DrawAutoSections(List<SerializedProperty> properties)
        {
            if (properties == null || properties.Count == 0 || target == null)
            {
                return;
            }

            List<SerializedProperty> references = new();
            List<SerializedProperty> settings = new();
            List<SerializedProperty> debug = new();

            for (int i = 0; i < properties.Count; i++)
            {
                SerializedProperty p = properties[i];
                if (p == null)
                {
                    continue;
                }

                if (IsDebugProperty(p))
                {
                    debug.Add(p);
                }
                else if (IsReferenceProperty(p))
                {
                    references.Add(p);
                }
                else
                {
                    settings.Add(p);
                }
            }

            Color baseGreen = CustomEditorSettings.ScriptNameColor;
            var darkGreen = Color.Lerp(baseGreen, Color.black, 0.75f);

            DrawAutoSection("References", references, baseGreen, darkGreen);
            DrawAutoSection("Settings", settings, baseGreen, darkGreen);
            DrawAutoSection("Debug", debug, baseGreen, darkGreen);
        }

        private void DrawAutoSection(string title, List<SerializedProperty> props, Color baseColor, Color darkColor)
        {
            if (props == null || props.Count == 0 || target == null)
            {
                return;
            }

            string key = $"{target.GetType().FullName}.NeoFoldout.Auto.{title}";
            bool expanded = GetFoldoutState(key, true);

            Color accent = expanded ? darkColor : baseColor;
            Color titleColor = expanded ? Color.white : baseColor;
            expanded = DrawNeoSectionHeader(expanded, title, props.Count, accent, "d_Folder Icon", titleColor);
            _neoFoldouts[key] = expanded;

            if (!expanded)
            {
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.indentLevel++;
                for (int i = 0; i < props.Count; i++)
                {
                    DrawPropertyField(props[i], false);
                }

                EditorGUI.indentLevel--;
            }
        }

        private bool IsReferenceProperty(SerializedProperty property)
        {
            if (property == null || target == null)
            {
                return false;
            }

            if (property.propertyType == SerializedPropertyType.ObjectReference)
            {
                return true;
            }

            if (!TryGetFieldInfoForPropertyPath(target.GetType(), property.propertyPath, out FieldInfo fieldInfo))
            {
                return false;
            }

            Type t = fieldInfo.FieldType;
            if (t == null)
            {
                return false;
            }

            if (typeof(Object).IsAssignableFrom(t))
            {
                return true;
            }

            if (t.IsArray)
            {
                Type element = t.GetElementType();
                return element != null && typeof(Object).IsAssignableFrom(element);
            }

            if (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(List<>))
            {
                Type element = t.GetGenericArguments()[0];
                return element != null && typeof(Object).IsAssignableFrom(element);
            }

            return false;
        }

        private static bool IsDebugProperty(SerializedProperty property)
        {
            if (property == null)
            {
                return false;
            }

            string name = property.name ?? string.Empty;
            string path = property.propertyPath ?? string.Empty;

            return name.Contains("debug", StringComparison.OrdinalIgnoreCase) ||
                   name.Contains("gizmo", StringComparison.OrdinalIgnoreCase) ||
                   name.Contains("editor", StringComparison.OrdinalIgnoreCase) ||
                   path.Contains("debug", StringComparison.OrdinalIgnoreCase) ||
                   path.Contains("gizmo", StringComparison.OrdinalIgnoreCase);
        }

        private void DrawPropertyField(SerializedProperty property, bool suppressUnityHeaderDecorators)
        {
            if (property == null)
            {
                return;
            }

            DrawNetworkReplicationMarker(property);

            if (property.propertyType == SerializedPropertyType.Boolean)
            {
                DrawBooleanToggle(property);
                return;
            }

            // WHY: we already render the [Header] title as our own section header, so suppress Unity's built-in
            // header decorator around EVERY draw path (collection/nested/plain) to avoid doubling the title —
            // previously arrays/generics returned early and their [Header] rendered a second time.
            if (suppressUnityHeaderDecorators && !string.IsNullOrEmpty(TryGetHeaderTitleForProperty(property)))
            {
                RunWithHeaderDecoratorsSuppressed(property, () => DrawPropertyFieldBody(property));
                return;
            }

            DrawPropertyFieldBody(property);
        }

        /// <summary>
        ///     Escape hatch for a derived inspector that has to own the rendering of ONE field while every
        ///     other field keeps the standard pass - a list that also accepts asset drops, for instance.
        ///     Return <c>true</c> once the property has been drawn; the base draw is then skipped.
        /// </summary>
        protected virtual bool DrawCustomProperty(SerializedProperty property)
        {
            return false;
        }

        private void DrawPropertyFieldBody(SerializedProperty property)
        {
            // Inside the body rather than in DrawPropertyField so the override still runs with the
            // [Header] decorator suppressed - the section header already printed that title.
            if (DrawCustomProperty(property))
            {
                return;
            }

            DrawStandardProperty(property);
        }

        /// <summary>
        ///     The normal draw for one property. Exposed so an override of <see cref="DrawCustomProperty" />
        ///     can still get the standard look and only add to it.
        /// </summary>
        protected void DrawStandardProperty(SerializedProperty property)
        {
            if (!CustomEditorSettings.UseDefaultListAndArrayDrawing && ShouldUseCollectionPropertyFoldout(property))
            {
                DrawCollectionPropertyFoldout(property);
                return;
            }

            if (ShouldUseNestedPropertyFoldout(property))
            {
                DrawNestedPropertyFoldout(property);
                return;
            }

            EditorGUILayout.PropertyField(property, true);
        }

        private void DrawCollectionPropertyFoldout(SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            Color accent = IsDebugProperty(property)
                ? new Color(0.94f, 0.34f, 0.34f, 1f)
                : new Color(0.92f, 0.72f, 0.28f, 1f);

            property.isExpanded = DrawNestedFoldoutHeader(property.displayName, property.arraySize, property.isExpanded,
                accent);
            if (!property.isExpanded)
            {
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                SerializedProperty iterator = property.Copy();
                SerializedProperty endProperty = iterator.GetEndProperty();
                int directChildDepth = property.depth + 1;
                bool enterChildren = true;

                while (iterator.NextVisible(enterChildren) && !SerializedProperty.EqualContents(iterator, endProperty))
                {
                    enterChildren = false;
                    if (iterator.depth != directChildDepth)
                    {
                        continue;
                    }

                    DrawPropertyField(iterator.Copy(), false);
                }
            }
        }

        private void DrawNestedPropertyFoldout(SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            int childCount = CountDirectVisibleChildren(property);
            Color accent = IsDebugProperty(property)
                ? new Color(0.92f, 0.30f, 0.30f, 1f)
                : new Color(0.40f, 0.66f, 0.98f, 1f);

            property.isExpanded =
                DrawNestedFoldoutHeader(property.displayName, childCount, property.isExpanded, accent);
            if (!property.isExpanded)
            {
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                SerializedProperty iterator = property.Copy();
                SerializedProperty endProperty = iterator.GetEndProperty();
                int directChildDepth = property.depth + 1;
                bool enterChildren = true;

                while (iterator.NextVisible(enterChildren) && !SerializedProperty.EqualContents(iterator, endProperty))
                {
                    enterChildren = false;
                    if (iterator.depth != directChildDepth)
                    {
                        continue;
                    }

                    DrawPropertyField(iterator.Copy(), false);
                }
            }
        }

        private static bool ShouldUseCollectionPropertyFoldout(SerializedProperty property)
        {
            if (property == null)
            {
                return false;
            }

            if (IsUnityEventProperty(property))
            {
                return false;
            }

            return property.isArray && property.propertyType != SerializedPropertyType.String;
        }

        private static bool ShouldUseNestedPropertyFoldout(SerializedProperty property)
        {
            if (property == null)
            {
                return false;
            }

            if (IsUnityEventProperty(property))
            {
                return false;
            }

            // WHY: Let CustomPropertyDrawer run for the whole serialized class (e.g. ComponentFloatBinding), instead of
            // expanding child fields and bypassing the drawer.
            if (string.Equals(property.type, "ComponentFloatBinding", StringComparison.Ordinal))
            {
                return false;
            }

            if (property.propertyType != SerializedPropertyType.Generic || !property.hasVisibleChildren)
            {
                return false;
            }

            if (property.isArray)
            {
                return false;
            }

            return CountDirectVisibleChildren(property) > 0;
        }

        private static int CountDirectVisibleChildren(SerializedProperty property)
        {
            if (property == null || !property.hasVisibleChildren)
            {
                return 0;
            }

            SerializedProperty iterator = property.Copy();
            SerializedProperty endProperty = iterator.GetEndProperty();
            int directChildDepth = property.depth + 1;
            int count = 0;
            bool enterChildren = true;

            while (iterator.NextVisible(enterChildren) && !SerializedProperty.EqualContents(iterator, endProperty))
            {
                enterChildren = false;
                if (iterator.depth == directChildDepth)
                {
                    count++;
                }
            }

            return count;
        }

        private static bool DrawNestedFoldoutHeader(string title, int count, bool expanded, Color accent)
        {
            const float height = 22f;

            Rect row = GUILayoutUtility.GetRect(0f, height + 2f, GUILayout.ExpandWidth(true));
            row = EditorGUI.IndentedRect(row);
            Rect rect = new(row.x, row.y + 1f, row.width, height);

            bool isHover = rect.Contains(Event.current.mousePosition);
            bool pro = NeoInspectorTheme.IsDark;
            Color background = Color.Lerp(NeoInspectorTheme.SectionBackground, accent,
                expanded ? 0.14f : isHover ? 0.11f : 0.07f);

            NeoInspectorTheme.DrawRoundedRect(rect, background,
                new Color(accent.r, accent.g, accent.b, isHover || expanded ? 0.35f : 0.18f),
                NeoInspectorTheme.RadiusRow, 1f);
            NeoInspectorTheme.DrawAccentRail(rect, accent, 2.5f, 4f);

            if (Event.current.type == EventType.MouseDown &&
                Event.current.button == 0 &&
                rect.Contains(Event.current.mousePosition))
            {
                expanded = !expanded;
                GUI.FocusControl(null);
                Event.current.Use();
            }

            GUIStyle arrowStyle = new(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = pro ? Color.Lerp(Color.white, accent, 0.15f) : Color.Lerp(accent, Color.black, 0.2f) }
            };
            GUIStyle titleStyle = new(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleLeft,
                clipping = TextClipping.Clip,
                normal = { textColor = NeoInspectorTheme.TitleText }
            };

            Color pillBg = Color.Lerp(accent, pro ? Color.black : Color.white, 0.08f);
            pillBg.a = expanded ? 0.92f : 0.78f;
            GUIStyle countStyle = new(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = NeoInspectorTheme.ReadableOn(pillBg) }
            };

            float countW = Mathf.Max(24f, countStyle.CalcSize(new GUIContent(count.ToString())).x + 14f);
            Rect arrowRect = new(rect.x + 8f, rect.y, 12f, rect.height);
            Rect countRect = new(rect.xMax - countW - 8f, rect.y + (rect.height - 16f) * 0.5f, countW, 16f);
            Rect titleRect = new(arrowRect.xMax + 5f, rect.y, countRect.x - arrowRect.xMax - 10f, rect.height);

            GUI.Label(arrowRect, expanded ? "▼" : "▶", arrowStyle);
            GUI.Label(titleRect, title, titleStyle);

            NeoInspectorTheme.DrawRoundedRect(countRect, pillBg, NeoInspectorTheme.RadiusPill);
            GUI.Label(countRect, count.ToString(), countStyle);

            return expanded;
        }

        /// <summary>
        ///     Draws <paramref name="property" /> WITHOUT its Unity <c>[Header]</c> decorator. Module editors
        ///     that render their OWN section header (a Foldout/label) call this instead of
        ///     <see cref="EditorGUILayout.PropertyField(SerializedProperty, bool)" /> so the title is not shown
        ///     twice (once as the section header, once as the field's built-in header).
        /// </summary>
        protected void DrawPropertyFieldNoHeader(SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            // WHY: match the standard property pass — booleans render as the styled ON/OFF toggle, not a
            // plain checkbox. DrawBooleanToggle draws no [Header] decorator, so it never doubles the title.
            if (property.propertyType == SerializedPropertyType.Boolean)
            {
                DrawBooleanToggle(property);
                return;
            }

            RunWithHeaderDecoratorsSuppressed(property, () => EditorGUILayout.PropertyField(property, true));
        }

        /// <summary>
        ///     Draws a collapsible section in the STANDARD Neoxider style (green foldout bar + count badge,
        ///     body in a help box) for module editors that keep manual control over which fields they show.
        ///     Use <see cref="DrawPropertyFieldNoHeader" /> inside <paramref name="drawBody" /> so a field's
        ///     <c>[Header]</c> does not double the section title. Reuses the same look/persistence as the
        ///     auto-generated <c>[Header]</c> sections so custom component editors match the rest of the package.
        /// </summary>
        protected void DrawNeoSection(string title, int count, Action drawBody)
        {
            if (drawBody == null)
            {
                return;
            }

            Color baseGreen = CustomEditorSettings.ScriptNameColor;
            var darkGreen = Color.Lerp(baseGreen, Color.black, 0.75f);
            string key = $"{(target != null ? target.GetType().FullName : "Neo")}.NeoFoldout.Header.{title}";
            bool expanded = GetFoldoutState(key, true);

            Color accent = expanded ? darkGreen : baseGreen;
            Color titleColor = expanded ? Color.white : baseGreen;
            expanded = DrawNeoSectionHeader(expanded, title, count, accent, "d_Folder Icon", titleColor);
            _neoFoldouts[key] = expanded;
            if (!expanded)
            {
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.indentLevel++;
                drawBody();
                EditorGUI.indentLevel--;
            }
        }

        // WHY: temporarily strip the built-in HeaderDrawer from the property handler so `draw` renders the
        // field WITHOUT Unity's [Header] label (we already drew that title as our own section header). Wraps
        // ALL draw paths — plain, collection foldout and nested foldout — so array/generic fields with a
        // [Header] no longer double the title.
        internal static void RunWithHeaderDecoratorsSuppressed(SerializedProperty property, Action draw)
        {
            if (property == null)
            {
                return;
            }

            if (_getHandlerMethod == null)
            {
                draw();
                return;
            }

            object handler = null;
            try
            {
                handler = _getHandlerMethod.Invoke(null, new object[] { property });
            }
            catch
            {
                draw();
                return;
            }

            if (handler == null)
            {
                draw();
                return;
            }

            FieldInfo decoratorsField =
                handler.GetType().GetField("m_DecoratorDrawers", BindingFlags.Instance | BindingFlags.NonPublic);
            if (decoratorsField == null)
            {
                draw();
                return;
            }

            object originalDecorators = null;
            try
            {
                originalDecorators = decoratorsField.GetValue(handler);
                if (originalDecorators is IList list)
                {
                    IList filtered = (IList)Activator.CreateInstance(decoratorsField.FieldType);
                    for (int i = 0; i < list.Count; i++)
                    {
                        object d = list[i];
                        if (d == null)
                        {
                            continue;
                        }

                        if (d.GetType().Name == "HeaderDrawer")
                        {
                            continue;
                        }

                        filtered.Add(d);
                    }

                    decoratorsField.SetValue(handler, filtered);
                }
            }
            catch
            {
                // Decorator suppression is optional; the draw callback must still run exactly once.
            }

            try
            {
                draw();
            }
            finally
            {
                if (originalDecorators != null)
                {
                    try
                    {
                        decoratorsField.SetValue(handler, originalDecorators);
                    }
                    catch
                    {
                    }
                }
            }
        }

        // WHY delegated: the pill is the package's boolean, and a PropertyDrawer (which cannot inherit this
        // class) needs to draw the same thing inside nested serialized types. One definition, in
        // NeoxiderEditorGUI; this stays as the layout-based entry point the property pass uses.
        private void DrawBooleanToggle(SerializedProperty property)
        {
            Rect rect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            GUIContent label = new(property.displayName, property.tooltip);
            NeoxiderEditorGUI.DrawPillToggleField(rect, property, label);
        }

        private List<HeaderSection> BuildHeaderSections(List<SerializedProperty> properties)
        {
            List<HeaderSection> sections = new();
            int i = 0;
            while (i < properties.Count)
            {
                SerializedProperty p = properties[i];
                string headerTitle = TryGetHeaderTitleForProperty(p);

                if (string.IsNullOrEmpty(headerTitle))
                {
                    List<SerializedProperty> general = new();
                    while (i < properties.Count && string.IsNullOrEmpty(TryGetHeaderTitleForProperty(properties[i])))
                    {
                        general.Add(properties[i]);
                        i++;
                    }

                    if (general.Count > 0)
                    {
                        sections.Add(new HeaderSection("General", general, false));
                    }

                    continue;
                }

                List<SerializedProperty> sectionProps = new();
                sectionProps.Add(p);
                i++;

                while (i < properties.Count && string.IsNullOrEmpty(TryGetHeaderTitleForProperty(properties[i])))
                {
                    sectionProps.Add(properties[i]);
                    i++;
                }

                bool looksLikeWarning =
                    headerTitle.StartsWith("⚠", StringComparison.Ordinal) ||
                    headerTitle.StartsWith("!", StringComparison.Ordinal) ||
                    headerTitle.Contains("warning", StringComparison.OrdinalIgnoreCase) ||
                    headerTitle.Contains("error", StringComparison.OrdinalIgnoreCase);

                bool isWarningHeader = looksLikeWarning;
                sections.Add(new HeaderSection(headerTitle, sectionProps, isWarningHeader));
            }

            return sections;
        }

        private void DrawWarningHeader(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return;
            }

            bool pro = NeoInspectorTheme.IsDark;
            Rect row = GUILayoutUtility.GetRect(0f, 30f, GUILayout.ExpandWidth(true));
            row = EditorGUI.IndentedRect(row);
            Rect rect = new(row.x, row.y + 2f, row.width, 26f);

            Color accent = new(1f, 0.34f, 0.34f, 1f);
            Color background = pro
                ? new Color(0.34f, 0.11f, 0.11f, 0.85f)
                : new Color(0.98f, 0.90f, 0.90f, 1f);

            NeoInspectorTheme.DrawRoundedRect(rect, background,
                new Color(accent.r, accent.g, accent.b, 0.4f), NeoInspectorTheme.RadiusRow, 1f);
            NeoInspectorTheme.DrawAccentRail(rect, accent, 4f, 5f);

            GUIStyle style = new(EditorStyles.boldLabel)
            {
                fontSize = 14,
                wordWrap = false,
                clipping = TextClipping.Clip,
                alignment = TextAnchor.MiddleLeft,
                normal = { textColor = pro ? new Color(1f, 0.86f, 0.86f, 1f) : new Color(0.55f, 0.12f, 0.12f, 1f) }
            };

            GUI.Label(new Rect(rect.x + 13f, rect.y, rect.width - 20f, rect.height), text, style);
            EditorGUILayout.Space(2);
        }

        private static bool IsDebugHeaderTitle(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            return text.Contains("debug", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("gizmo", StringComparison.OrdinalIgnoreCase);
        }

        private void DrawPlainHeader(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return;
            }

            bool isDebug = IsDebugHeaderTitle(text);
            Rect row = GUILayoutUtility.GetRect(0f, 24f, GUILayout.ExpandWidth(true));
            row = EditorGUI.IndentedRect(row);
            Rect rect = new(row.x, row.y + 2f, row.width, 20f);

            Color accent = isDebug
                ? new Color(0.94f, 0.34f, 0.34f, 1f)
                : new Color(0.44f, 0.62f, 0.96f, 1f);
            Color background = Color.Lerp(NeoInspectorTheme.HeaderRowBackground, accent, 0.10f);

            NeoInspectorTheme.DrawRoundedRect(rect, background, NeoInspectorTheme.RadiusRow);
            NeoInspectorTheme.DrawAccentRail(rect, accent, 3f, 4f);

            GUIStyle style = new(EditorStyles.boldLabel)
            {
                fontSize = 12,
                wordWrap = false,
                clipping = TextClipping.Clip,
                alignment = TextAnchor.MiddleLeft,
                normal = { textColor = isDebug ? Color.Lerp(NeoInspectorTheme.TitleText, accent, 0.35f) : NeoInspectorTheme.TitleText }
            };

            GUI.Label(new Rect(rect.x + 12f, rect.y, rect.width - 18f, rect.height), text, style);
            EditorGUILayout.Space(1);
        }

        // WHY: Header titles and field lookups depend only on (type, property path) and are requested several
        // times per property on every IMGUI event; reflect once and reuse the answer. The cap keeps huge arrays
        // (one path per element) from growing the cache without bound.
        private const int MaxReflectionCacheEntries = 4096;
        private static readonly Dictionary<(Type, string), string> s_headerTitleCache = new();
        private static readonly Dictionary<(Type, string), FieldInfo> s_fieldPathCache = new();

        internal string TryGetHeaderTitleForProperty(SerializedProperty property)
        {
            if (property == null || target == null)
            {
                return null;
            }

            (Type, string) key = (target.GetType(), property.propertyPath);
            if (s_headerTitleCache.TryGetValue(key, out string cached))
            {
                return cached;
            }

            string title = ResolveHeaderTitle(key.Item1, key.Item2);
            if (s_headerTitleCache.Count >= MaxReflectionCacheEntries)
            {
                s_headerTitleCache.Clear();
            }

            s_headerTitleCache[key] = title;
            return title;
        }

        private static string ResolveHeaderTitle(Type rootType, string propertyPath)
        {
            if (!TryGetFieldInfoForPropertyPath(rootType, propertyPath, out FieldInfo fieldInfo))
            {
                return null;
            }

            try
            {
                object[] attrs = fieldInfo.GetCustomAttributes(typeof(HeaderAttribute), true);
                if (attrs == null || attrs.Length == 0)
                {
                    return null;
                }

                HeaderAttribute header = attrs[0] as HeaderAttribute;
                return header?.header;
            }
            catch
            {
                return null;
            }
        }

        private static bool TryGetFieldInfoForPropertyPath(Type rootType, string propertyPath, out FieldInfo fieldInfo)
        {
            fieldInfo = null;
            if (rootType == null || string.IsNullOrEmpty(propertyPath))
            {
                return false;
            }

            (Type, string) key = (rootType, propertyPath);
            if (s_fieldPathCache.TryGetValue(key, out FieldInfo cached))
            {
                fieldInfo = cached;
                return cached != null;
            }

            bool found = ResolveFieldInfoForPropertyPath(rootType, propertyPath, out fieldInfo);
            if (s_fieldPathCache.Count >= MaxReflectionCacheEntries)
            {
                s_fieldPathCache.Clear();
            }

            s_fieldPathCache[key] = fieldInfo;
            return found;
        }

        private static bool ResolveFieldInfoForPropertyPath(Type rootType, string propertyPath,
            out FieldInfo fieldInfo)
        {
            fieldInfo = null;
            string[] parts = propertyPath.Split('.');
            Type currentType = rootType;
            FieldInfo currentField = null;

            for (int i = 0; i < parts.Length; i++)
            {
                string part = parts[i];

                if (part == "Array")
                {
                    continue;
                }

                if (part.StartsWith("data[", StringComparison.Ordinal))
                {
                    continue;
                }

                currentField = currentType.GetField(part,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                if (currentField == null)
                {
                    return false;
                }

                currentType = currentField.FieldType;

                if (currentType.IsArray)
                {
                    currentType = currentType.GetElementType();
                }
                else if (currentType.IsGenericType &&
                         currentType.GetGenericTypeDefinition() == typeof(List<>))
                {
                    currentType = currentType.GetGenericArguments()[0];
                }
            }

            fieldInfo = currentField;
            return fieldInfo != null;
        }

        private bool GetFoldoutState(string key, bool defaultValue)
        {
            if (string.IsNullOrEmpty(key))
            {
                return defaultValue;
            }

            if (_neoFoldouts.TryGetValue(key, out bool value))
            {
                return value;
            }

            _neoFoldouts[key] = defaultValue;
            return defaultValue;
        }

        private static bool IsUnityEventProperty(SerializedProperty property)
        {
            if (property == null)
            {
                return false;
            }

            string typeName = property.type;
            if (!string.IsNullOrEmpty(typeName) && typeName.Contains("UnityEvent"))
            {
                return true;
            }

            if (property.propertyType != SerializedPropertyType.Generic)
            {
                return false;
            }

            SerializedProperty calls = property.FindPropertyRelative("m_PersistentCalls.m_Calls");
            return calls != null && calls.isArray;
        }

        private void DrawNetworkReplicationMarker(SerializedProperty property)
        {
            if (!IsNetworkReplicationHighlighted(property))
            {
                return;
            }

            Rect rect = GUILayoutUtility.GetRect(0f, 18f, GUILayout.ExpandWidth(true));
            rect = EditorGUI.IndentedRect(rect);

            bool pro = NeoInspectorTheme.IsDark;
            Color accent = new(0.22f, 0.78f, 1f, 1f);
            Color background = pro ? new Color(0.06f, 0.16f, 0.23f, 0.92f) : new Color(0.86f, 0.94f, 0.99f, 1f);
            NeoInspectorTheme.DrawRoundedRect(rect, background, NeoInspectorTheme.RadiusRow);
            NeoInspectorTheme.DrawAccentRail(rect, accent, 3f, 3f);

            GUIStyle style = new(EditorStyles.miniBoldLabel)
            {
                normal = { textColor = pro ? new Color(0.68f, 0.92f, 1f, 1f) : new Color(0.12f, 0.40f, 0.55f, 1f) },
                alignment = TextAnchor.MiddleLeft
            };

            GUI.Label(new Rect(rect.x + 10f, rect.y, rect.width - 10f, rect.height),
                "NETWORK REPLICATED when isNetworked is enabled", style);
        }

        private bool IsNetworkReplicationHighlighted(SerializedProperty property)
        {
            if (property == null || target == null || !IsNetworkedEnabled())
            {
                return false;
            }

            if (IsUnityEventProperty(property))
            {
                return IsReplicatedUnityEventProperty(property);
            }

            return IsReplicatedReactiveProperty(property);
        }

        private bool IsNetworkedEnabled()
        {
            SerializedProperty networked = serializedObject?.FindProperty("isNetworked");
            if (networked != null && networked.propertyType == SerializedPropertyType.Boolean)
            {
                return networked.boolValue;
            }

            SerializedProperty privateNetworked = serializedObject?.FindProperty("_isNetworked");
            return privateNetworked != null &&
                   privateNetworked.propertyType == SerializedPropertyType.Boolean &&
                   privateNetworked.boolValue;
        }

        private bool IsReplicatedUnityEventProperty(SerializedProperty property)
        {
            string propertyName = property.name ?? string.Empty;
            string propertyPath = property.propertyPath ?? string.Empty;
            string targetName = target.GetType().Name;

            if (targetName == "InteractiveObject")
            {
                return propertyName == "onInteractDown" ||
                       propertyName == "onInteractUp" ||
                       propertyName == "onClick" ||
                       propertyName == "onDoubleClick" ||
                       propertyName == "onRightClick" ||
                       propertyName == "onMiddleClick";
            }

            if (targetName == "NetworkEventDispatcher")
            {
                return propertyName == "onNetworkEvent";
            }

            if (targetName == "NetworkActionRelay")
            {
                return propertyName == "onTriggered" ||
                       propertyName == "onTriggeredFloat" ||
                       propertyName == "onTriggeredString" ||
                       propertyPath.EndsWith(".onTriggered", StringComparison.Ordinal) ||
                       propertyPath.EndsWith(".onTriggeredFloat", StringComparison.Ordinal) ||
                       propertyPath.EndsWith(".onTriggeredString", StringComparison.Ordinal);
            }

            if (targetName == "Counter")
            {
                return propertyName == "OnValueChangedInt" ||
                       propertyName == "OnValueChangedFloat" ||
                       propertyName == "OnRepeatByCounterValue";
            }

            if (targetName == "RandomRange")
            {
                return propertyName == "OnGeneratedInt" ||
                       propertyName == "OnGeneratedFloat";
            }

            if (targetName == "Selector")
            {
                return propertyName == "OnSelectionChanged" ||
                       propertyName == "OnSelectionChangedGameObject" ||
                       propertyName == "OnCountActiveChanged";
            }

            if (targetName == "NeoCondition")
            {
                return propertyName == "_onTrue" ||
                       propertyName == "_onFalse" ||
                       propertyName == "_onResult" ||
                       propertyName == "_onInvertedResult";
            }

            if (targetName == "Spawner")
            {
                return propertyName == "OnObjectSpawned" ||
                       propertyName == "OnWaveStarted" ||
                       propertyName == "OnWaveObjectSpawned";
            }

            return false;
        }

        private bool IsReplicatedReactiveProperty(SerializedProperty property)
        {
            string propertyType = property.type ?? string.Empty;
            if (!propertyType.Contains("ReactiveProperty", StringComparison.Ordinal))
            {
                return false;
            }

            string targetName = target.GetType().Name;
            string propertyName = property.name ?? string.Empty;

            return (targetName == "Counter" || targetName == "RandomRange") &&
                   propertyName == "Value";
        }

        private static SerializedProperty GetPersistentCallsArray(SerializedProperty unityEventProperty)
        {
            if (unityEventProperty == null)
            {
                return null;
            }

            SerializedProperty calls = unityEventProperty.FindPropertyRelative("m_PersistentCalls.m_Calls");
            if (calls != null && calls.isArray)
            {
                return calls;
            }

            return null;
        }

        private static int GetPersistentCallCount(SerializedProperty unityEventProperty)
        {
            SerializedProperty calls = GetPersistentCallsArray(unityEventProperty);
            return calls != null ? calls.arraySize : 0;
        }

        private static int GetBrokenPersistentCallCount(SerializedProperty unityEventProperty)
        {
            SerializedProperty calls = GetPersistentCallsArray(unityEventProperty);
            if (calls == null)
            {
                return 0;
            }

            int broken = 0;
            for (int i = 0; i < calls.arraySize; i++)
            {
                SerializedProperty call = calls.GetArrayElementAtIndex(i);
                if (call == null)
                {
                    continue;
                }

                SerializedProperty targetProp = call.FindPropertyRelative("m_Target");
                SerializedProperty methodProp = call.FindPropertyRelative("m_MethodName");

                bool hasTarget = targetProp != null &&
                                 targetProp.propertyType == SerializedPropertyType.ObjectReference &&
                                 targetProp.objectReferenceValue != null;
                bool hasMethod = methodProp != null &&
                                 methodProp.propertyType == SerializedPropertyType.String &&
                                 !string.IsNullOrWhiteSpace(methodProp.stringValue);

                if (!hasTarget || !hasMethod)
                {
                    broken++;
                }
            }

            return broken;
        }

        private static string BuildPersistentCallPreview(SerializedProperty unityEventProperty, int maxItems)
        {
            SerializedProperty calls = GetPersistentCallsArray(unityEventProperty);
            if (calls == null || calls.arraySize == 0 || maxItems <= 0)
            {
                return null;
            }

            int count = Mathf.Min(calls.arraySize, maxItems);
            List<string> parts = new(count);

            for (int i = 0; i < count; i++)
            {
                SerializedProperty call = calls.GetArrayElementAtIndex(i);
                if (call == null)
                {
                    continue;
                }

                SerializedProperty targetProp = call.FindPropertyRelative("m_Target");
                SerializedProperty methodProp = call.FindPropertyRelative("m_MethodName");

                string targetName = targetProp != null &&
                                    targetProp.propertyType == SerializedPropertyType.ObjectReference &&
                                    targetProp.objectReferenceValue != null
                    ? targetProp.objectReferenceValue.name
                    : "<Missing Target>";

                string methodName = methodProp != null &&
                                    methodProp.propertyType == SerializedPropertyType.String &&
                                    !string.IsNullOrWhiteSpace(methodProp.stringValue)
                    ? methodProp.stringValue
                    : "<Missing Method>";

                parts.Add($"{targetName}.{methodName}");
            }

            if (parts.Count == 0)
            {
                return null;
            }

            string preview = string.Join(", ", parts);
            if (calls.arraySize > maxItems)
            {
                preview += $" … (+{calls.arraySize - maxItems})";
            }

            return preview;
        }

        private static readonly Color NeoPropAccent = new(0.49f, 0.60f, 0.94f, 1f);

        private static GUIStyle _neoPropertyPanelStyle;
        private Rect _neoPanelRect;

        /// <summary>Layout-only style for the property card; the visual is drawn by
        /// <see cref="DrawNeoPropertyPanelBackground" /> so the corners can actually be rounded.</summary>
        private static GUIStyle GetNeoPropertyPanelStyle()
        {
            return _neoPropertyPanelStyle ??= new GUIStyle
            {
                padding = new RectOffset(12, 12, 10, 10),
                margin = new RectOffset(0, 0, 2, 4)
            };
        }

        /// <summary>Rounded card behind the default property fields with a faint accent tint.</summary>
        private static void DrawNeoPropertyPanelBackground(Rect rect)
        {
            Color fill = Color.Lerp(NeoInspectorTheme.PanelBackground, NeoPropAccent, 0.05f);
            Color edge = new(NeoPropAccent.r, NeoPropAccent.g, NeoPropAccent.b, 0.14f);
            NeoInspectorTheme.DrawRoundedRect(rect, fill, edge, NeoInspectorTheme.RadiusCard, 1f);
        }

        /// <summary>A non-collapsible themed section label (accent rail + icon + title) for the property block.</summary>
        private void DrawNeoSectionLabel(string title, string iconName)
        {
            const float height = 26f;
            Rect row = GUILayoutUtility.GetRect(0, height + 2f, GUILayout.ExpandWidth(true));
            row = EditorGUI.IndentedRect(row);
            Rect rect = new(row.x, row.y + 1f, row.width, height);

            bool pro = NeoInspectorTheme.IsDark;
            Color accent = NeoPropAccent;
            Color bg = Color.Lerp(NeoInspectorTheme.HeaderRowBackground, accent, 0.08f);
            NeoInspectorTheme.DrawRoundedRect(rect, bg, new Color(accent.r, accent.g, accent.b, 0.22f),
                NeoInspectorTheme.RadiusSection, 1f);
            NeoInspectorTheme.DrawAccentRail(rect, accent, 3f, 6f);

            float x = rect.x + 14f;
            GUIContent iconContent = string.IsNullOrEmpty(iconName) ? null : EditorGUIUtility.IconContent(iconName);
            if (iconContent != null && iconContent.image != null && Event.current.type == EventType.Repaint)
            {
                Rect iconRect = new(x, rect.y + (rect.height - 15f) * 0.5f, 15f, 15f);
                Color old = GUI.color;
                GUI.color = pro ? Color.Lerp(Color.white, accent, 0.14f) : Color.Lerp(accent, Color.black, 0.15f);
                GUI.DrawTexture(iconRect, (Texture2D)iconContent.image, ScaleMode.ScaleToFit, true);
                GUI.color = old;
                x += 20f;
            }

            GUIStyle titleStyle = new(EditorStyles.boldLabel)
            {
                fontSize = 12,
                alignment = TextAnchor.MiddleLeft,
                clipping = TextClipping.Clip,
                normal = { textColor = pro ? new Color(0.88f, 0.90f, 0.96f, 1f) : NeoInspectorTheme.TitleText }
            };
            GUI.Label(new Rect(x, rect.y, Mathf.Max(20f, rect.width - (x - rect.x) - 8f), rect.height), title,
                titleStyle);
        }

        private bool DrawNeoSectionHeader(bool expanded,
            string title,
            int count,
            Color accent,
            string iconName,
            Color titleColor)
        {
            // WHY delegated: this bar IS the Neoxider section, and nested drawers need to draw the same one.
            // The single definition lives in NeoxiderEditorGUI; this keeps the layout/indent handling.
            Rect row = GUILayoutUtility.GetRect(0, NeoxiderEditorGUI.SectionHeaderHeight + 3f,
                GUILayout.ExpandWidth(true));
            row = EditorGUI.IndentedRect(row);
            Rect rect = new(row.x, row.y + 2f, row.width, NeoxiderEditorGUI.SectionHeaderHeight);

            return NeoxiderEditorGUI.DrawSectionHeaderRect(rect, expanded, title, count, accent, iconName,
                titleColor);
        }

        private readonly struct HeaderSection
        {
            public readonly string Title;
            public readonly List<SerializedProperty> Properties;
            public readonly bool IsWarningHeader;

            public HeaderSection(string title, List<SerializedProperty> properties, bool isWarningHeader)
            {
                Title = title;
                Properties = properties;
                IsWarningHeader = isWarningHeader;
            }
        }
    }
}
