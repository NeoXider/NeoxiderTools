using UnityEngine;
using UnityEngine.Events;

namespace Neo.Animations
{
    /// <summary>
    ///     Universal animator for colors. Provides an easy way to animate color with various animation types.
    /// </summary>
    [NeoDoc("Animations/ColorAnimator.md")]
    [CreateFromMenu("Neoxider/Animations/ColorAnimator")]
    [AddComponentMenu("Neoxider/" + "Animations/" + nameof(ColorAnimator))]
    public class ColorAnimator : MonoBehaviour
    {
        [Header("Animation Settings")] [Tooltip("Animation type")]
        public AnimationType animationType = AnimationType.PerlinNoise;

        [Header("Color Settings")] [Tooltip("Start color")]
        public Color startColor = Color.white;

        [Tooltip("End color")] public Color endColor = Color.red;

        [Tooltip("Animation speed (0 = disabled)")] [Range(0f, 30f)]
        public float animationSpeed = 1.0f;

        [Header("Noise Settings")] [Tooltip("Noise scale for PerlinNoise")] [Range(0.1f, 20f)]
        public float noiseScale = 1f;

        [Tooltip("Use 2D noise instead of 1D")]
        public bool use2DNoise = true;

        [Tooltip("Additional noise offset")] public Vector2 noiseOffset;

        [Header("Custom Curve")] [Tooltip("Custom curve for CustomCurve type")]
        public AnimationCurve customCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

        [Header("Control")] [Tooltip("Auto-start animation on Start")]
        public bool playOnStart = true;

        [Tooltip("Invoked when color changes")]
        public UnityEvent<Color> OnColorChanged;

        [Tooltip("Invoked when animation starts")]
        public UnityEvent OnAnimationStarted;

        [Tooltip("Invoked when animation stops")]
        public UnityEvent OnAnimationStopped;

        [Tooltip("Invoked when animation is paused")]
        public UnityEvent OnAnimationPaused;

        private float animationTime;
        private Color lastColor;
        private Vector2 randomOffset;

        /// <summary>Current animated color (read-only).</summary>
        public Color CurrentColor { get; private set; }

        /// <summary>Whether the animation is currently playing.</summary>
        public bool IsPlaying { get; private set; }

        /// <summary>Whether the animation is paused.</summary>
        public bool IsPaused { get; private set; }

        /// <summary>Start color (writable from outside).</summary>
        public Color StartColor
        {
            get => startColor;
            set => startColor = value;
        }

        /// <summary>End color (writable from outside).</summary>
        public Color EndColor
        {
            get => endColor;
            set => endColor = value;
        }

        /// <summary>Animation speed (writable from outside).</summary>
        public float AnimationSpeed
        {
            get => animationSpeed;
            set => animationSpeed = value;
        }

        /// <summary>Animation type (writable from outside).</summary>
        public AnimationType AnimationType
        {
            get => animationType;
            set => animationType = value;
        }

        private void Start()
        {
            animationTime = Random.Range(0f, 1000f);
            randomOffset = new Vector2(Random.Range(-1000f, 1000f),
                Random.Range(-1000f, 1000f));

            CurrentColor = startColor;
            lastColor = startColor;

            if (playOnStart)
            {
                Play();
            }
        }

        private void Update()
        {
            if (!IsPlaying || IsPaused)
            {
                return;
            }

            animationTime += Time.deltaTime;

            Color newColor = AnimationUtils.GetAnimatedColor(
                animationType,
                startColor, endColor,
                animationTime, animationSpeed,
                use2DNoise, randomOffset, noiseOffset, noiseScale,
                customCurve);

            CurrentColor = newColor;

            if (ColorDistance(newColor, lastColor) > 0.001f)
            {
                OnColorChanged?.Invoke(newColor);
                lastColor = newColor;
            }
        }

        /// <summary>Starts the animation.</summary>
        [Button(PlayModeOnly = true)]
        public void Play()
        {
            IsPlaying = true;
            IsPaused = false;
            OnAnimationStarted?.Invoke();
        }

        /// <summary>Stops the animation.</summary>
        [Button(PlayModeOnly = true)]
        public void Stop()
        {
            IsPlaying = false;
            IsPaused = false;
            OnAnimationStopped?.Invoke();
        }

        /// <summary>Pauses the animation.</summary>
        [Button(PlayModeOnly = true)]
        public void Pause()
        {
            if (IsPlaying)
            {
                IsPaused = true;
                OnAnimationPaused?.Invoke();
            }
        }

        /// <summary>Resumes the animation from pause.</summary>
        [Button(PlayModeOnly = true)]
        public void Resume()
        {
            if (IsPaused)
            {
                IsPaused = false;
                OnAnimationStarted?.Invoke();
            }
        }

        /// <summary>Resets animation time to zero.</summary>
        public void ResetTime()
        {
            animationTime = 0f;
        }

        /// <summary>Sets a random initial animation time.</summary>
        public void RandomizeTime()
        {
            animationTime = Random.Range(0f, 1000f);
        }

        /// <summary>Computes distance between two colors.</summary>
        private float ColorDistance(Color a, Color b)
        {
            return Mathf.Sqrt(
                Mathf.Pow(a.r - b.r, 2) +
                Mathf.Pow(a.g - b.g, 2) +
                Mathf.Pow(a.b - b.b, 2) +
                Mathf.Pow(a.a - b.a, 2)
            );
        }
    }
}
