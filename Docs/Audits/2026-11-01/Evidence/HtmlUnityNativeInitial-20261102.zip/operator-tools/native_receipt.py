"""Task-owned native receipt helper; never mutates project files."""
import argparse
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/Git/NeoxiderTools')
BASE = Path('D:/Temp/Neoxider-Audit-20261101')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def protected():
    baseline = json.loads((BASE / 'pre-main-merge.json').read_text(encoding='utf-8'))['files']
    differences = []
    for relative, expected in baseline.items():
        path = ROOT / relative
        if path.exists() != expected['exists'] or (path.is_file() and sha(path) != expected.get('sha256')):
            differences.append(relative)
    return {'count': len(baseline), 'differences': differences}

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['freeze', 'summarize'])
parser.add_argument('name')
args = parser.parse_args()
if not args.name or any(character not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for character in args.name):
    raise SystemExit('Invalid owned run name')
freeze = BASE / 'native-20261102' / (args.name + '-inputs')
run = BASE / 'native-20261102' / args.name
if args.action == 'freeze':
    freeze.mkdir(parents=True, exist_ok=False)
    paths = set()
    for relative in ['Assets/Neoxider/Scripts/UI/HtmlToUitk', 'Assets/Neoxider/Tests/Edit/HtmlToUitk', 'Assets/HtmlToUitkShowcase']:
        directory = ROOT / relative
        if directory.is_dir():
            paths.update(path for path in directory.rglob('*') if path.is_file())
    files = {}
    for source in sorted(paths):
        relative = source.relative_to(ROOT).as_posix()
        target = freeze / 'sources' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        files[relative] = {'sha256': sha(target), 'bytes': target.stat().st_size}
    status = subprocess.check_output(['git', 'status', '--porcelain', '-uall'], cwd=ROOT, encoding='utf-8')
    manifest = {'frozenUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'root': str(ROOT), 'scope': 'HTML module sources/tests and existing showcase; source copies before native run', 'files': files, 'protected': protected(), 'gitStatus': status}
    if manifest['protected']['differences']:
        raise SystemExit('Protected paths changed: ' + repr(manifest['protected']))
    write(freeze / 'manifest.json', manifest)
    print(json.dumps({'frozenFiles': len(files), 'manifest': str(freeze / 'manifest.json'), 'protected': manifest['protected']}))
else:
    launch = json.loads((run / 'launch.json').read_text(encoding='utf-8-sig'))
    tree = ET.parse(run / 'results.xml').getroot()
    cases = list(tree.iter('test-case'))
    counters = collections.Counter(case.get('result') for case in cases)
    fixtures = collections.defaultdict(collections.Counter)
    for suite in tree.iter('test-suite'):
        if suite.get('type') == 'TestFixture':
            fixtures[suite.get('fullname')] += collections.Counter(case.get('result') for case in suite.iter('test-case'))
    frozen = json.loads((freeze / 'manifest.json').read_text(encoding='utf-8'))
    changes = [relative for relative, expected in frozen['files'].items() if not (ROOT / relative).is_file() or sha(ROOT / relative) != expected['sha256']]
    failures = [{'name': case.get('fullname'), 'result': case.get('result'), 'message': case.findtext('failure/message'), 'stack': case.findtext('failure/stack-trace')} for case in cases if case.get('result') not in ['Passed']]
    result = {'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'nativeExitCode': launch.get('ExitCode'), 'rootCounters': tree.attrib, 'actualCaseCount': len(cases), 'caseResults': dict(counters), 'fixtures': {key: dict(value) for key, value in fixtures.items()}, 'nonPassing': failures, 'frozenInputCount': len(frozen['files']), 'changedFrozenPaths': changes, 'protected': protected(), 'evidenceHashes': {name: sha(run / name) for name in ['launch.json', 'results.xml', 'editor.log']}, 'qualification': 'Actual graphical batch Editor execution. No manual or physical input, ordinary visible Game View, Player, IL2CPP or arbitrary web-backend proof.'}
    write(run / 'result-summary.json', result)
    print(json.dumps({key: result[key] for key in ['nativeExitCode', 'actualCaseCount', 'caseResults', 'fixtures', 'nonPassing', 'frozenInputCount', 'changedFrozenPaths', 'protected']}, ensure_ascii=False))
