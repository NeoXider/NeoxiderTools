using System;
using Neo.Editor;
using Neo.Pages;
using UnityEditor;
using UnityEngine;

namespace Neo.Pages.Editor
{
    [CustomEditor(typeof(UIPage))]
    public sealed class UIPageEditor : CustomEditorBase
    {
        private const float ModeButtonHeight = 22f;
        private const string SourceLabelAll = "Source: all project folders";
        private SerializedProperty animationModeProp;

        private string generateName = "Menu";
        private SerializedProperty ignoreOnExclusiveChangeProp;
        private SerializedProperty pageIdProp;
        private SerializedProperty popupProp;
        private int selectorMode; // WHY: 0 = dropdown, 1 = asset

        protected override bool UseCustomNeoxiderInspectorGUI => true;
        protected override string NeoxiderModuleName => "Neoxider Pages";

        private void OnEnable()
        {
            pageIdProp = serializedObject.FindProperty("pageId");
            popupProp = serializedObject.FindProperty("popup");
            ignoreOnExclusiveChangeProp = serializedObject.FindProperty("ignoreOnExclusiveChange");
            animationModeProp = serializedObject.FindProperty("_animationMode");
        }

        protected override void DrawCustomNeoxiderInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.LabelField("Page", EditorStyles.boldLabel);
            DrawPageIdSelector(pageIdProp);
            DrawPropertyIfAvailable(popupProp, "Popup");
            DrawPropertyIfAvailable(ignoreOnExclusiveChangeProp, "Ignore On Exclusive Change");

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("Anim", EditorStyles.boldLabel);
            DrawPropertyIfAvailable(animationModeProp, "Animation Mode");
            EditorGUILayout.HelpBox(
                "Compatibility setting for older scenes and project extensions. The base NeoxiderPages sample has no required tween dependency.",
                MessageType.Info);

            serializedObject.ApplyModifiedProperties();
        }

        protected override void ProcessAttributeAssignments()
        {
            // WHY: Pages inspectors do not use auto-assign from NeoCustomEditor.
        }

        private void DrawPageIdSelector(SerializedProperty pageId)
        {
            if (pageId == null)
            {
                EditorGUILayout.HelpBox("Serialized field 'pageId' was not found on UIPage.", MessageType.Warning);
                return;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Page Id", EditorStyles.miniBoldLabel);
                selectorMode = DrawSegmentedMode(selectorMode,
                    new GUIContent("Dropdown", "Pick from PageId assets in the folder"),
                    new GUIContent("Asset", "Manually pick a specific PageId asset"));
                EditorGUILayout.Space(2);

                if (selectorMode == 0)
                {
                    PageId[] ids = FindAllPageIds(null);
                    if (ids.Length == 0)
                    {
                        EditorGUILayout.HelpBox(
                            "There are no PageId assets in the project.\nCreate a PageId manually or generate one via menu: Tools → Neo → Pages → Generate Default PageIds.",
                            MessageType.Warning);
                        return;
                    }

                    string[] labels = PageIdEditorCache.GetLabels(null);

                    var current = pageId.objectReferenceValue as PageId;
                    int currentIdx = current == null ? 0 : Array.FindIndex(ids, x => x == current) + 1;
                    if (currentIdx < 0)
                    {
                        currentIdx = 0;
                    }

                    int newIdx = EditorGUILayout.Popup(new GUIContent("Page"), currentIdx, labels);
                    if (newIdx == 0)
                    {
                        pageId.objectReferenceValue = null;
                    }
                    else if (newIdx > 0 && newIdx <= ids.Length)
                    {
                        pageId.objectReferenceValue = ids[newIdx - 1];
                    }

                    EditorGUILayout.LabelField(SourceLabelAll, EditorStyles.miniLabel);
                }
                else
                {
                    EditorGUILayout.PropertyField(pageId, new GUIContent("Page Id (asset)"));
                }
            }

            DrawGenerateAndAssign(pageId);
        }

        private static void DrawPropertyIfAvailable(SerializedProperty property, string label)
        {
            if (property == null)
            {
                EditorGUILayout.HelpBox($"Serialized field for '{label}' was not found on UIPage.", MessageType.Warning);
                return;
            }

            EditorGUILayout.PropertyField(property);
        }

        private static int DrawSegmentedMode(int value, GUIContent left, GUIContent right)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = value;

                Color prevBg = GUI.backgroundColor;
                Color prevContent = GUI.contentColor;

                DrawModeButton(0, left, ref selected, EditorStyles.miniButtonLeft);
                DrawModeButton(1, right, ref selected, EditorStyles.miniButtonRight);

                GUI.backgroundColor = prevBg;
                GUI.contentColor = prevContent;

                return selected;
            }
        }

        private static void DrawModeButton(int index, GUIContent content, ref int selected, GUIStyle style)
        {
            bool isSelected = selected == index;
            GUI.backgroundColor = isSelected ? GetSelectedBackgroundColor() : Color.white;
            GUI.contentColor = isSelected ? GetSelectedContentColor() : Color.white;

            if (GUILayout.Button(content, style, GUILayout.Height(ModeButtonHeight)))
            {
                selected = index;
            }
        }

        private static Color GetSelectedBackgroundColor()
        {
            return EditorGUIUtility.isProSkin
                ? new Color(0.25f, 0.55f, 0.95f, 1f)
                : new Color(0.20f, 0.45f, 0.90f, 1f);
        }

        private static Color GetSelectedContentColor()
        {
            return Color.white;
        }

        private void DrawGenerateAndAssign(SerializedProperty pageId)
        {
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Generate", EditorStyles.miniBoldLabel);
            var current = pageId.objectReferenceValue as PageId;
            if (current != null)
            {
                generateName = current.DisplayName;
            }

            using (new EditorGUI.DisabledScope(current != null))
            {
                generateName = EditorGUILayout.TextField("Page Name", generateName);
            }

            using (new EditorGUI.DisabledScope(current != null || string.IsNullOrWhiteSpace(generateName)))
            {
                if (GUILayout.Button("Generate & Assign"))
                {
                    string folder = PageIdGenerator.GetPreferredFolder();
                    string normalizedName = generateName;
                    string assetName = normalizedName.Trim().StartsWith("Page", StringComparison.Ordinal)
                        ? normalizedName.Trim()
                        : "Page" + normalizedName.Trim();
                    string path = $"{folder}/{assetName}.asset";
                    bool alreadyExists = AssetDatabase.LoadAssetAtPath<PageId>(path) != null;

                    PageId id = PageIdGenerator.GetOrCreate(normalizedName, folder);
                    if (id != null)
                    {
                        if (alreadyExists)
                        {
                            Debug.LogWarning($"[UIPage] PageId already exists: {path}. Assigned existing.",
                                (UIPage)target);
                        }

                        pageId.objectReferenceValue = id;
                    }
                }
            }
        }

        private static PageId[] FindAllPageIds(string folder = null)
        {
            return PageIdEditorCache.GetIds(folder);
        }
    }
}
