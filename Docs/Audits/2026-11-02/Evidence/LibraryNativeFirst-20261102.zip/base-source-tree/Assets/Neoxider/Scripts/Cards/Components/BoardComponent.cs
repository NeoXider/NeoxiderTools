using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

namespace Neo.Cards
{
    /// <summary>
    ///     Shared table board (e.g. five community cards in Hold'em or a discard pile in Durak).
    /// </summary>
    [CreateFromMenu("Neoxider/Cards/BoardComponent")]
    [AddComponentMenu("Neoxider/Cards/" + nameof(BoardComponent))]
    [NeoDoc("Cards/BoardComponent.md")]
    public class BoardComponent : MonoBehaviour
    {
        [Header("Layout")] [SerializeField] private Transform[] _cardSlots;

        [SerializeField] private float _slotSpacing = 80f;
        [SerializeField] private bool _autoGenerateSlots = true;
        [SerializeField] private BoardMode _mode = BoardMode.Table;
        [SerializeField] private CardLayoutType _layoutType = CardLayoutType.Slots;
        [SerializeField] private CardLayoutSettings _layoutSettings;
        [SerializeField] private StackZSortingStrategy _stackZSorting = StackZSortingStrategy.TopCardFirst;

        [Tooltip(
            "Local override. If empty, Board falls back to the assigned DeckComponent or global animation config.")]
        [SerializeField]
        private CardAnimationConfig _animationConfig;

        [Tooltip("Optional Deck source for settings. If local config is empty, Board will use config from here.")]
        [SerializeField]
        private DeckComponent _settingsSourceDeck;

        [Header("Settings")] [SerializeField] private int _maxCards = 5;

        [SerializeField] private bool _faceUp;

        [Tooltip("Whether to automatically increase max card count when returning")] [SerializeField]
        private bool _autoExpandCapacity = true;

        [Header("Sources (for reset)")] [Tooltip("Hands from which to take cards on reset/restart")] [SerializeField]
        private List<HandComponent> _handSources = new();

        [Tooltip("Other BoardComponents to clear into this Board")] [SerializeField]
        private List<BoardComponent> _boardSources = new();

        [Tooltip("Additional root objects from which CardComponents will be collected")] [SerializeField]
        private List<Transform> _extraRoots = new();

        [Header("Debug")] [Tooltip("Last collected list of cards from RestoreAllSourcesToBoard")] [SerializeField]
        private List<CardComponent> _lastCollectedCards = new();

        [Tooltip("Cards created at initial spawn (Initial Board)")] [SerializeField]
        private List<CardComponent> _initialSpawnedCards = new();

        [Header("Animation")] [SerializeField] private float _placeDuration = 0.3f;

        public UnityEvent<CardComponent> OnCardPlaced;

        public UnityEvent OnBoardFull;
        public UnityEvent OnBoardCleared;

        [SerializeField] private List<CardComponent> _cards = new();

        private CancellationToken _ct;
        private CancellationTokenSource _layoutCancellation;
        private int _layoutRevision;
        private int _clearGeneration;
        private int _nextMembershipVersion;
        private readonly Dictionary<CardComponent, int> _membershipVersions = new();

        /// <summary>
        ///     Cards on this board.
        /// </summary>
        public IReadOnlyList<CardComponent> Cards => _cards;

        /// <summary>
        ///     Card count.
        /// </summary>
        public int Count => _cards.Count;

        /// <summary>
        ///     Whether the board has no cards.
        /// </summary>
        public bool IsEmpty => _cards.Count == 0;

        /// <summary>
        ///     Whether the board reached capacity.
        /// </summary>
        public bool IsFull => _cards.Count >= _maxCards;

        /// <summary>
        ///     Maximum cards this board accepts before reporting full.
        /// </summary>
        public int MaxCards => _maxCards;

        /// <summary>
        ///     Face-up state applied to newly placed cards when overrideFaceUp is true.
        /// </summary>
        public bool FaceUp => _faceUp;

        /// <summary>
        ///     Slot transforms for slot layout mode.
        /// </summary>
        public Transform[] CardSlots => _cardSlots;

        private void Awake()
        {
            _ct = this.GetCancellationTokenOnDestroy();

            if (_autoGenerateSlots && (_cardSlots == null || _cardSlots.Length == 0))
            {
                GenerateSlots();
            }
        }

        private void OnDestroy()
        {
            InvalidateLayout();
        }

        /// <summary>
        ///     Places a card on the board.
        /// </summary>
        /// <param name="card">Card to place.</param>
        /// <param name="animate">Tween into slot/layout.</param>
        /// <param name="overrideFaceUp">If true, apply this component's FaceUp flag.</param>
        public async UniTask PlaceCardAsync(CardComponent card, bool animate = true, bool overrideFaceUp = true)
        {
            if (!CanPlaceCard(card))
            {
                return;
            }

            InvalidateLayout();
            card.transform.SetParent(transform, true);

            if (overrideFaceUp)
            {
                card.IsFaceUp = _faceUp;
            }

            _cards.Add(card);
            int membershipVersion = ++_nextMembershipVersion;
            _membershipVersions[card] = membershipVersion;
            await ArrangeCardsInternalAsync(animate);

            if (IsCurrentMember(card, membershipVersion))
            {
                OnCardPlaced?.Invoke(card);
                if (IsCurrentMember(card, membershipVersion) && IsFull)
                {
                    OnBoardFull?.Invoke();
                }
            }
        }

        /// <summary>
        ///     Places without awaiting (no tween).
        /// </summary>
        /// <param name="card">Card.</param>
        public void PlaceCard(CardComponent card)
        {
            PlaceCardAsync(card, false).SuppressCancellationThrow().Forget();
        }

        /// <summary>
        ///     Returns whether the board can accept this card right now.
        /// </summary>
        /// <param name="card">Card to place.</param>
        public bool CanPlaceCard(CardComponent card)
        {
            return card != null && !IsFull && !_cards.Contains(card);
        }

        /// <summary>
        ///     Updates board capacity for custom layouts/games.
        /// </summary>
        /// <param name="maxCards">New maximum card count.</param>
        /// <param name="regenerateSlots">Regenerate auto slots immediately.</param>
        public void SetCapacity(int maxCards, bool regenerateSlots = true)
        {
            InvalidateLayout();
            _maxCards = Mathf.Max(0, maxCards);

            if (regenerateSlots && _autoGenerateSlots)
            {
                GenerateSlots();
            }

            ArrangeCardsInternalAsync(false).SuppressCancellationThrow().Forget();
        }

        /// <summary>
        ///     Updates default face state for newly placed cards.
        /// </summary>
        /// <param name="faceUp">Face-up state.</param>
        /// <param name="applyToExisting">Apply to cards already on the board.</param>
        public void SetFaceUp(bool faceUp, bool applyToExisting = false)
        {
            _faceUp = faceUp;

            if (!applyToExisting)
            {
                return;
            }

            foreach (CardComponent card in _cards)
            {
                if (card != null)
                {
                    card.IsFaceUp = faceUp;
                }
            }
        }

        /// <summary>
        ///     Re-runs layout for every card on the board.
        /// </summary>
        [Button("Arrange Cards")]
        public void ArrangeCards()
        {
            ArrangeCardsInternalAsync(true).SuppressCancellationThrow().Forget();
        }

        /// <summary>
        ///     Places even when full by bumping capacity (restart helpers).
        /// </summary>
        /// <param name="card">Card.</param>
        /// <param name="animate">Tween.</param>
        /// <param name="overrideFaceUp">Apply FaceUp flag.</param>
        private async UniTask ForcePlaceCardAsync(CardComponent card, bool animate = false, bool overrideFaceUp = true)
        {
            if (card == null || _cards.Contains(card))
            {
                return;
            }

            if (_autoExpandCapacity && IsFull)
            {
                _maxCards = Mathf.Max(_maxCards + 1, _cards.Count + 1);
                if (_autoGenerateSlots)
                {
                    GenerateSlots();
                }
            }

            await PlaceCardAsync(card, animate, overrideFaceUp);
        }

        /// <summary>
        ///     Marks a card spawned during initial board setup.
        /// </summary>
        /// <param name="card">Card.</param>
        public void RegisterInitialCard(CardComponent card)
        {
            if (card == null)
            {
                return;
            }

            if (!_initialSpawnedCards.Contains(card))
            {
                _initialSpawnedCards.Add(card);
            }
        }

        /// <summary>
        ///     Places multiple cards sequentially.
        /// </summary>
        /// <param name="cards">Cards.</param>
        /// <param name="animate">Tween each.</param>
        /// <param name="delayBetweenCards">Delay seconds between placements.</param>
        public async UniTask PlaceCardsAsync(IEnumerable<CardComponent> cards, bool animate = true,
            float delayBetweenCards = 0.1f)
        {
            int generation = _clearGeneration;
            List<CardComponent> snapshot = new(cards);
            foreach (CardComponent card in snapshot)
            {
                if (IsFull)
                {
                    break;
                }

                await PlaceCardAsync(card, animate);
                if (generation != _clearGeneration)
                {
                    return;
                }

                if (delayBetweenCards > 0)
                {
                    await UniTask.Delay((int)(delayBetweenCards * 1000), cancellationToken: _ct);
                    if (generation != _clearGeneration)
                    {
                        return;
                    }
                }
            }
        }

        /// <summary>
        ///     Removes a specific card.
        /// </summary>
        /// <param name="card">Card.</param>
        /// <returns>True if it was on the board.</returns>
        public bool RemoveCard(CardComponent card)
        {
            if (card == null)
            {
                return false;
            }

            bool removed = _cards.Remove(card);
            if (removed)
            {
                InvalidateLayout();
                _membershipVersions.Remove(card);
                card.CancelAnimation();
                card.transform.SetParent(null, true);
                ArrangeCardsInternalAsync(false).SuppressCancellationThrow().Forget();
            }

            return removed;
        }

        /// <summary>
        ///     Removes by index.
        /// </summary>
        /// <param name="index">Index.</param>
        /// <returns>Removed card, or null.</returns>
        public CardComponent RemoveAt(int index)
        {
            if (index < 0 || index >= _cards.Count)
            {
                return null;
            }

            CardComponent card = _cards[index];
            RemoveCard(card);
            return card;
        }

        /// <summary>
        ///     Destroys every card on the board.
        /// </summary>
        [Button]
        public void Clear()
        {
            InvalidateLayout();
            _clearGeneration++;
            _membershipVersions.Clear();
            foreach (CardComponent card in _cards)
            {
                if (card != null)
                {
                    card.CancelAnimation();
                    Destroy(card.gameObject);
                }
            }

            _cards.Clear();
            OnBoardCleared?.Invoke();
        }

        /// <summary>
        ///     Detaches and returns cards without destroying them.
        /// </summary>
        /// <returns>Former board cards.</returns>
        public List<CardComponent> ClearAndReturn()
        {
            InvalidateLayout();
            _clearGeneration++;
            _membershipVersions.Clear();
            List<CardComponent> cards = new(_cards);

            foreach (CardComponent card in cards)
            {
                if (card != null)
                {
                    card.CancelAnimation();
                    card.transform.SetParent(null, true);
                }
            }

            _cards.Clear();
            OnBoardCleared?.Invoke();

            return cards;
        }

        /// <summary>
        ///     Flips every card instantly.
        /// </summary>
        [Button]
        public void FlipAll()
        {
            FlipAllAsync().SuppressCancellationThrow().Forget();
        }

        /// <summary>
        ///     Pulls cards from configured hands, other boards, and extra roots back onto this board.
        /// </summary>
        [Button]
        public void RestoreAllSourcesToBoard()
        {
            RestoreAllSourcesToBoardAsync().SuppressCancellationThrow().Forget();
        }

        /// <summary>
        ///     Async variant of <see cref="RestoreAllSourcesToBoard" />.
        /// </summary>
        public async UniTask RestoreAllSourcesToBoardAsync()
        {
            List<CardComponent> collected = new();
            HashSet<CardComponent> seen = new();

            foreach (HandComponent hand in _handSources)
            {
                if (hand == null)
                {
                    continue;
                }

                while (hand.Count > 0)
                {
                    CardComponent card = hand.DrawFirst();
                    if (card != null && seen.Add(card))
                    {
                        collected.Add(card);
                    }
                    else
                    {
                        break;
                    }
                }
            }

            foreach (BoardComponent board in _boardSources)
            {
                if (board == null || board == this)
                {
                    continue;
                }

                List<CardComponent> returned = board.ClearAndReturn();
                foreach (CardComponent card in returned)
                {
                    if (card != null && seen.Add(card))
                    {
                        collected.Add(card);
                    }
                }
            }

            foreach (Transform root in _extraRoots)
            {
                if (root == null)
                {
                    continue;
                }

                CardComponent[] cards = root.GetComponentsInChildren<CardComponent>(true);
                foreach (CardComponent card in cards)
                {
                    if (card == null || card.transform == transform)
                    {
                        continue;
                    }

                    if (seen.Add(card))
                    {
                        collected.Add(card);
                    }
                }
            }

            foreach (CardComponent card in collected)
            {
                await ForcePlaceCardAsync(card);
            }

            _lastCollectedCards.Clear();
            _lastCollectedCards.AddRange(collected);

            OnBoardCleared?.Invoke();
        }

        /// <summary>
        ///     Flips every card with tween spacing.
        /// </summary>
        /// <param name="delayBetweenCards">Seconds between flips.</param>
        public async UniTask FlipAllAsync(float delayBetweenCards = 0.1f)
        {
            int revision = _layoutRevision;
            CardComponent[] cards = _cards.ToArray();
            foreach (CardComponent card in cards)
            {
                if (revision != _layoutRevision || card == null || card.transform.parent != transform)
                {
                    return;
                }

                await card.FlipAsync();
                if (revision != _layoutRevision)
                {
                    return;
                }

                if (delayBetweenCards > 0)
                {
                    await UniTask.Delay((int)(delayBetweenCards * 1000), cancellationToken: _ct);
                }
            }
        }

        /// <summary>
        ///     Distinct non-joker ranks currently on the board.
        /// </summary>
        /// <returns>Rank set.</returns>
        public HashSet<Rank> GetAllRanks()
        {
            HashSet<Rank> ranks = new();

            foreach (CardComponent card in _cards)
            {
                if (!card.Data.IsJoker)
                {
                    ranks.Add(card.Data.Rank);
                }
            }

            return ranks;
        }

        /// <summary>
        ///     Copies <see cref="CardData" /> for each board card.
        /// </summary>
        /// <returns>Data list.</returns>
        public List<CardData> GetAllCardData()
        {
            List<CardData> data = new();

            foreach (CardComponent card in _cards)
            {
                data.Add(card.Data);
            }

            return data;
        }

        private Transform GetSlot(int index)
        {
            if (_cardSlots == null || _cardSlots.Length == 0)
            {
                return transform;
            }

            if (index < 0 || index >= _cardSlots.Length)
            {
                return transform;
            }

            return _cardSlots[index];
        }

        private bool ShouldUseSlotPlacement()
        {
            return _mode == BoardMode.Table && _layoutType == CardLayoutType.Slots;
        }

        private CardLayoutType ResolveLayoutType()
        {
            if (_mode == BoardMode.Beat)
            {
                return CardLayoutType.Scattered;
            }

            return _layoutType;
        }

        private async UniTask ArrangeCardsInternalAsync(bool animate)
        {
            InvalidateLayout();
            if (_cards.Count == 0)
            {
                return;
            }

            CardLayoutSettings settings = _layoutSettings;
            if (settings.Spacing == 0f && settings.ArcRadius == 0f && settings.GridColumns == 0)
            {
                settings = CardLayoutSettings.Default;
                settings.Spacing = _slotSpacing;
            }

            CardAnimationConfig resolvedAnimationConfig = ResolveAnimationConfig();
            if (resolvedAnimationConfig != null)
            {
                settings.StackStep = resolvedAnimationConfig.StackStepY;
                settings.PositionJitter = resolvedAnimationConfig.StackPositionJitter;
                settings.RotationJitter = resolvedAnimationConfig.StackRotationJitter;
            }

            int revision = _layoutRevision;
            CardComponent[] cards = _cards.ToArray();
            bool slots = ShouldUseSlotPlacement();
            CardLayoutType layoutType = ResolveLayoutType();
            List<Vector3> positions = CardLayoutCalculator.CalculatePositions(layoutType, cards.Length, settings);
            List<Quaternion> rotations = CardLayoutCalculator.CalculateRotations(layoutType, cards.Length, settings);
            using CancellationTokenSource layout = CancellationTokenSource.CreateLinkedTokenSource(_ct);
            _layoutCancellation = layout;
            try
            {
                for (int i = 0; i < cards.Length; i++)
                {
                    if (revision != _layoutRevision || layout.IsCancellationRequested)
                    {
                        return;
                    }

                    CardComponent card = cards[i];
                    if (card == null || card.transform.parent != transform)
                    {
                        continue;
                    }

                    int sibling = _stackZSorting == StackZSortingStrategy.TopCardFirst ? i : cards.Length - 1 - i;
                    card.transform.SetSiblingIndex(sibling);
                    if (revision != _layoutRevision || card == null || card.transform.parent != transform)
                    {
                        return;
                    }

                    Transform slot = slots ? GetSlot(i) : null;
                    if (slots && slot == null)
                    {
                        continue;
                    }

                    Vector3 worldPosition = slots ? slot.position : transform.TransformPoint(positions[i]);
                    if (animate)
                    {
                        await card.MoveToAsync(worldPosition, _placeDuration, layout.Token);
                    }
                    else
                    {
                        card.transform.position = worldPosition;
                    }

                    if (revision != _layoutRevision || card == null || card.transform.parent != transform)
                    {
                        return;
                    }

                    if (!slots)
                    {
                        card.transform.localRotation = rotations[i];
                    }

                    card.UpdateOriginalTransform();
                }
            }
            catch (OperationCanceledException) when (!_ct.IsCancellationRequested)
            {
                // Membership/layout changed; the replacement pass owns the current cards.
            }
            finally
            {
                if (ReferenceEquals(_layoutCancellation, layout))
                {
                    _layoutCancellation = null;
                }
            }
        }

        private bool IsCurrentMember(CardComponent card, int version)
        {
            return card != null && card.transform.parent == transform &&
                   _membershipVersions.TryGetValue(card, out int current) && current == version;
        }

        private void InvalidateLayout()
        {
            _layoutRevision++;
            CancellationTokenSource previous = _layoutCancellation;
            _layoutCancellation = null;
            previous?.Cancel();
        }

        private CardAnimationConfig ResolveAnimationConfig()
        {
            if (_animationConfig != null)
            {
                return _animationConfig;
            }

            if (_settingsSourceDeck != null && _settingsSourceDeck.AnimationConfig != null)
            {
                return _settingsSourceDeck.AnimationConfig;
            }

            return CardSettingsRuntime.GlobalAnimationConfig;
        }

        private void GenerateSlots()
        {
            // WHY: SetCapacity/ForcePlace regenerate slots at runtime; old auto-generated
            // slot objects must be destroyed or they accumulate under the board.
            if (_cardSlots != null)
            {
                foreach (Transform slot in _cardSlots)
                {
                    if (slot != null && slot != transform && slot.parent == transform)
                    {
                        Destroy(slot.gameObject);
                    }
                }
            }

            _cardSlots = new Transform[_maxCards];

            float totalWidth = (_maxCards - 1) * _slotSpacing;
            float startX = -totalWidth / 2f;

            for (int i = 0; i < _maxCards; i++)
            {
                GameObject slot = new($"Slot_{i}");
                slot.transform.SetParent(transform);
                slot.transform.localPosition = new Vector3(startX + i * _slotSpacing, 0, 0);
                slot.transform.localRotation = Quaternion.identity;
                _cardSlots[i] = slot.transform;
            }
        }
    }
}
