using System;
using Neo.Editor;
using Neo.Pages;
using UnityEditor;
using UnityEngine;

namespace Neo.Pages.Editor
{
    [CustomEditor(typeof(BtnChangePage))]
    public sealed class BtnChangePageEditor : CustomEditorBase
    {
        private const float ModeButtonHeight = 22f;
        private const string SourceLabelAll = "Source: all project folders";
        private SerializedProperty actionProp;
        private SerializedProperty canSwitchProp;

        private SerializedProperty changeTextProp;
        private SerializedProperty executeStateProp;
        private SerializedProperty imageTargetProp;

        private SerializedProperty intecactableProp;

        private SerializedProperty onClickProp;
        private SerializedProperty scaleAnimProp;

        private int selectorMode;
        private SerializedProperty targetPageIdProp;
        private SerializedProperty textPageProp;
        private SerializedProperty timeAnimImageProp;

        private SerializedProperty useAnimImageProp;

        protected override bool UseCustomNeoxiderInspectorGUI => true;
        protected override string NeoxiderModuleName => "Neoxider Pages";

        private void OnEnable()
        {
            intecactableProp = serializedObject.FindProperty("intecactable");
            imageTargetProp = serializedObject.FindProperty("_imageTarget");
            actionProp = serializedObject.FindProperty("action");
            targetPageIdProp = serializedObject.FindProperty("targetPageId");
            canSwitchProp = serializedObject.FindProperty("_canSwitchPage");
            executeStateProp = serializedObject.FindProperty("_executeState");

            useAnimImageProp = serializedObject.FindProperty("_useAnimImage");
            timeAnimImageProp = serializedObject.FindProperty("_timeAnimImage");
            scaleAnimProp = serializedObject.FindProperty("_scaleAnim");

            changeTextProp = serializedObject.FindProperty("_changeText");
            textPageProp = serializedObject.FindProperty("_textPage");

            onClickProp = serializedObject.FindProperty("OnClick");
        }

        protected override void DrawCustomNeoxiderInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.PropertyField(intecactableProp);
            EditorGUILayout.PropertyField(imageTargetProp);

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("Page Settings", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(actionProp);

            if ((BtnChangePage.Action)actionProp.enumValueIndex == BtnChangePage.Action.OpenPage)
            {
                DrawPageIdSelector(targetPageIdProp);
            }

            EditorGUILayout.PropertyField(canSwitchProp);
            EditorGUILayout.PropertyField(executeStateProp);

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("Animation", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(useAnimImageProp);
            if (useAnimImageProp.boolValue)
            {
                EditorGUILayout.PropertyField(timeAnimImageProp);
                EditorGUILayout.PropertyField(scaleAnimProp);
            }

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("SetText", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(changeTextProp);
            if (changeTextProp.boolValue)
            {
                EditorGUILayout.PropertyField(textPageProp);
            }

            EditorGUILayout.Space(8);
            EditorGUILayout.PropertyField(onClickProp);

            serializedObject.ApplyModifiedProperties();
        }

        protected override void ProcessAttributeAssignments()
        {
            // WHY: Pages inspectors do not use NeoCustomEditor auto-assign.
        }

        private void DrawPageIdSelector(SerializedProperty pageId)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Target Page", EditorStyles.miniBoldLabel);
                selectorMode = DrawSegmentedMode(selectorMode,
                    new GUIContent("Dropdown", "Pick from PageId assets in the folder"),
                    new GUIContent("Asset", "Manually assign a specific PageId asset"));
                EditorGUILayout.Space(2);

                if (selectorMode == 0)
                {
                    PageId[] ids = FindAllPageIds(null);
                    if (ids.Length == 0)
                    {
                        EditorGUILayout.HelpBox(
                            "No PageId assets in the project.\nCreate a PageId manually or generate via menu: Tools → Neo → Pages → Generate Default PageIds.",
                            MessageType.Warning);
                        return;
                    }

                    string[] labels = PageIdEditorCache.GetLabels(null);

                    var current = pageId.objectReferenceValue as PageId;
                    int currentIdx = current == null ? 0 : Array.FindIndex(ids, x => x == current) + 1;
                    if (currentIdx < 0)
                    {
                        currentIdx = 0;
                    }

                    int newIdx = EditorGUILayout.Popup(new GUIContent("Page"), currentIdx, labels);
                    if (newIdx == 0)
                    {
                        pageId.objectReferenceValue = null;
                    }
                    else if (newIdx > 0 && newIdx <= ids.Length)
                    {
                        pageId.objectReferenceValue = ids[newIdx - 1];
                    }

                    EditorGUILayout.LabelField(SourceLabelAll, EditorStyles.miniLabel);
                }
                else
                {
                    EditorGUILayout.PropertyField(pageId, new GUIContent("Page Id (asset)"));
                }
            }
        }

        private static int DrawSegmentedMode(int value, GUIContent left, GUIContent right)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = value;

                Color prevBg = GUI.backgroundColor;
                Color prevContent = GUI.contentColor;

                DrawModeButton(0, left, ref selected, EditorStyles.miniButtonLeft);
                DrawModeButton(1, right, ref selected, EditorStyles.miniButtonRight);

                GUI.backgroundColor = prevBg;
                GUI.contentColor = prevContent;

                return selected;
            }
        }

        private static void DrawModeButton(int index, GUIContent content, ref int selected, GUIStyle style)
        {
            bool isSelected = selected == index;
            GUI.backgroundColor = isSelected ? GetSelectedBackgroundColor() : Color.white;
            GUI.contentColor = isSelected ? GetSelectedContentColor() : Color.white;

            if (GUILayout.Button(content, style, GUILayout.Height(ModeButtonHeight)))
            {
                selected = index;
            }
        }

        private static Color GetSelectedBackgroundColor()
        {
            return EditorGUIUtility.isProSkin
                ? new Color(0.25f, 0.55f, 0.95f, 1f)
                : new Color(0.20f, 0.45f, 0.90f, 1f);
        }

        private static Color GetSelectedContentColor()
        {
            return Color.white;
        }

        private static PageId[] FindAllPageIds(string folder = null)
        {
            return PageIdEditorCache.GetIds(folder);
        }
    }
}
