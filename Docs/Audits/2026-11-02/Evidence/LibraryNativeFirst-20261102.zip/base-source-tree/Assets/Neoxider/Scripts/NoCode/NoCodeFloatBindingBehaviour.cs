using Neo.Reactive;
using UnityEngine;

namespace Neo.NoCode
{
    /// <summary>
    ///     Shared wiring: <see cref="ComponentFloatBinding"/>, optional reactive subscription, optional poll.
    /// </summary>
    [NeoDoc("NoCode/NoCodeFloatBindingBehaviour.md")]
    public abstract class NoCodeFloatBindingBehaviour : MonoBehaviour
    {
        private const float DefaultPollIntervalSeconds = 0.16f;
        private const float MinPollIntervalSeconds = 0.016f;

        [SerializeField] private ComponentFloatBinding _binding = new();

        [SerializeField] private NoCodeFloatUpdateMode _updateMode = NoCodeFloatUpdateMode.Reactive;

        [Tooltip("When Update Mode is Poll, refreshes in LateUpdate using Poll Interval.")] [SerializeField]
        private bool _pollInLateUpdate = true;

        [Tooltip(
            "Seconds between refreshes in Poll mode and Reactive fallback for ordinary fields. Default 0.16; minimum 0.016.")]
        [Min(MinPollIntervalSeconds)]
        [SerializeField]
        private float _pollIntervalSeconds = DefaultPollIntervalSeconds;

        private ReactivePropertyFloat _subscribedFloat;
        private ReactivePropertyInt _subscribedInt;
        private ReactivePropertyBool _subscribedBool;
        private float _nextPollTime;
        private bool _useReactivePollFallback;
        private volatile bool _configurationDirty;

        public ComponentFloatBinding Binding => _binding;

        private float PollIntervalSeconds => Mathf.Max(MinPollIntervalSeconds, _pollIntervalSeconds);

        private bool HasReactiveSubscription =>
            _subscribedFloat != null || _subscribedInt != null || _subscribedBool != null;

        protected virtual void OnValidate()
        {
            _pollIntervalSeconds = PollIntervalSeconds;
            _configurationDirty = true;
        }

        protected virtual void OnEnable()
        {
            _configurationDirty = false;
            _binding.Invalidate();
            _useReactivePollFallback = false;
            _nextPollTime = Time.unscaledTime + PollIntervalSeconds;
            TrySubscribeReactive();
            RefreshFromSource();
            TrySubscribeReactive();
        }

        protected virtual void OnDisable()
        {
            UnsubscribeReactive();
        }

        private void UnsubscribeReactive()
        {
            if (_subscribedFloat != null)
            {
                _subscribedFloat.RemoveListener(OnReactiveFloatChanged);
                _subscribedFloat = null;
            }

            if (_subscribedInt != null)
            {
                _subscribedInt.RemoveListener(OnReactiveIntChanged);
                _subscribedInt = null;
            }

            if (_subscribedBool != null)
            {
                _subscribedBool.RemoveListener(OnReactiveBoolChanged);
                _subscribedBool = null;
            }
        }

        protected virtual void LateUpdate()
        {
            if (!isActiveAndEnabled)
            {
                return;
            }

            ReconcileDirtyConfiguration();
            bool shouldPoll = _updateMode == NoCodeFloatUpdateMode.Poll ||
                              (_updateMode == NoCodeFloatUpdateMode.Reactive && _useReactivePollFallback);
            if (!shouldPoll || !_pollInLateUpdate)
            {
                return;
            }

            float now = Time.unscaledTime;
            if (now < _nextPollTime)
            {
                return;
            }

            RefreshFromSource();
            _nextPollTime = now + PollIntervalSeconds;
        }

        private void ReconcileDirtyConfiguration()
        {
            if (!_configurationDirty)
            {
                return;
            }

            // OnValidate may run off the main thread. Resolve sources only from refresh/LateUpdate.
            _configurationDirty = false;
            _binding.Invalidate();
            bool reactive = TrySubscribeReactive();
            _useReactivePollFallback = isActiveAndEnabled &&
                                       _updateMode == NoCodeFloatUpdateMode.Reactive && !reactive;
        }

        private void OnReactiveFloatChanged(float _)
        {
            if (isActiveAndEnabled)
            {
                RefreshFromSource();
            }
        }

        private void OnReactiveIntChanged(int _)
        {
            if (isActiveAndEnabled)
            {
                RefreshFromSource();
            }
        }

        private void OnReactiveBoolChanged(bool _)
        {
            if (isActiveAndEnabled)
            {
                RefreshFromSource();
            }
        }

        private bool TrySubscribeReactive()
        {
            if (!isActiveAndEnabled || _updateMode != NoCodeFloatUpdateMode.Reactive)
            {
                UnsubscribeReactive();
                return false;
            }

            if (!_binding.TryGetReactiveProperty(this, out ReactivePropertyFloat reactiveFloat,
                    out ReactivePropertyInt reactiveInt, out ReactivePropertyBool reactiveBool))
            {
                UnsubscribeReactive();
                return false;
            }

            if (ReferenceEquals(_subscribedFloat, reactiveFloat) &&
                ReferenceEquals(_subscribedInt, reactiveInt) &&
                ReferenceEquals(_subscribedBool, reactiveBool))
            {
                return true;
            }

            // Binding setters and replacement reactive instances take effect on the next refresh.
            UnsubscribeReactive();
            _useReactivePollFallback = false;
            if (reactiveFloat != null)
            {
                reactiveFloat.AddListener(OnReactiveFloatChanged);
                _subscribedFloat = reactiveFloat;
                return true;
            }

            if (reactiveInt != null)
            {
                reactiveInt.AddListener(OnReactiveIntChanged);
                _subscribedInt = reactiveInt;
                return true;
            }

            reactiveBool.AddListener(OnReactiveBoolChanged);
            _subscribedBool = reactiveBool;
            return true;
        }

        private void EnableReactivePollFallback()
        {
            if (!isActiveAndEnabled || _updateMode != NoCodeFloatUpdateMode.Reactive || HasReactiveSubscription)
            {
                return;
            }

            _useReactivePollFallback = true;
        }

        protected void RefreshFromSource()
        {
            ReconcileDirtyConfiguration();
            bool reactive = TrySubscribeReactive();
            if (!_binding.TryReadFloat(this, out float value))
            {
                // WHY: source not resolvable yet (late spawn / Wait For Object / Find By Name). In Reactive mode with
                // no subscription the LateUpdate poll is gated off, so without this the binding would freeze forever
                // and never retry once the object appears. Enable the poll fallback so resolution keeps being attempted.
                if (!reactive)
                {
                    EnableReactivePollFallback();
                }

                return;
            }

            ApplyFloat(value);
            reactive = TrySubscribeReactive();
            if (!reactive)
            {
                EnableReactivePollFallback();
            }
        }

        protected abstract void ApplyFloat(float value);

#if UNITY_EDITOR
        /// <summary>
        ///     Edit Mode tests / editor utilities: apply binding when <see cref="OnEnable"/> did not run or after wiring via serialized object.
        /// </summary>
        public void EditorInvokeRefreshFromSource()
        {
            RefreshFromSource();
        }
#endif
    }
}
